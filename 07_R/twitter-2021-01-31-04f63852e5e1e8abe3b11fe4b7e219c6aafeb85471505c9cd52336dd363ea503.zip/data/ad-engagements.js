window.YTD.ad_engagements.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1323183873530888193",
              "tweetText" : "[해양경찰청x웹툰] 아는만큼 안전한 바다이야기\n\n귀엽게 보면 큰코 다칠 수 있는 해파리의 위험성!\n아시나요?\n\n\"대한민국 해안도 해파리 주의보!?\"\n\n올바른 해파리 대처법!\n해양안전 정보 웹툰으로 알아보러 가볼까요~?\n👉https://t.co/NlknpLCrC6\n\n#해양경찰청 #해경 #웹툰 #인스타툰 #해파리쏘였을때 https://t.co/8dQWiekdf2",
              "urls" : [ "https://t.co/NlknpLCrC6" ],
              "mediaUrls" : [ "https://t.co/8dQWiekdf2" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "대한민국 해양경찰청",
              "screenName" : "@kcgpr122"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "웹툰"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-03 01:18:36"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-03 01:18:37",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322013831871094784",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75629",
              "name" : "#Apple20201103",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-02 18:37:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-02 18:42:01",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-02 18:41:57",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-02 18:42:05",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-02 18:42:01",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-02 18:43:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-02 18:48:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-02 18:41:59",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-02 18:46:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-02 18:42:09",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-02 18:42:08",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-02 18:37:29",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-02 18:42:09",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-02 23:55:10",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322013831871094784",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75629",
              "name" : "#Apple20201103",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-02 18:37:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-03 01:18:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-03 01:18:24",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "advertiserInfo" : {
              "advertiserName" : "샤이닝니키",
              "screenName" : "@ShiningNikki_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Sports themed"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "레진코믹스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다음웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "webcomic"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "연하공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "네이버웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install 샤이닝니키 IOS All"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-03 10:56:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-03 10:56:50",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-03 10:58:44",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010743324078082",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-03 10:56:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-03 11:27:33",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-03 10:56:14",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-03 10:58:44",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-03 10:56:23",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-03 10:59:26",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010883367735296",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "스마트hdr"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "5.9mmthinipadpro"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "macos"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "기술"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-09 11:59:46"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-09 11:59:49",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-09 12:00:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-09 11:59:53",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-09 12:01:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-09 11:59:53",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-09 12:11:11",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347052846114426881",
              "tweetText" : "마침내 손에 넣은 아름답고 강력한 힘.\n당신의 든든한 조력자 스타더스트를 지금 만나보세요.\n\n마비노기 스타더스트 업데이트\n\n자세히 알아보기 ▶ https://t.co/SqHb3TOsYv https://t.co/bQ3a6eZMec",
              "urls" : [ "https://t.co/SqHb3TOsYv" ],
              "mediaUrls" : [ "https://t.co/bQ3a6eZMec" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-13 08:40:50"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 08:40:53",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2021-01-13 08:40:54",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-13 08:40:58",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1349146642771939329",
              "tweetText" : "[#HMG_TV] 숲 속에서 들리는 소리를 듣고 있으면 마음이 편안해지죠? 🎶 #아이오닉5, Coming in early 2021. #현대자동차 #Hyundai #IONIQ #IONIQ5 #EV https://t.co/sY7kkZa3DT",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/sY7kkZa3DT" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "현대자동차그룹",
              "screenName" : "@hmg_talk"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "캠핑"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-13 09:54:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 09:57:11",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 09:54:16",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-13 09:54:16",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911011390353409",
              "tweetText" : "새롭게 선보이는 iPhone 12. 모든 카메라에서 야간 모드 지원.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-13 09:53:24"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 09:53:28",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-13 09:53:28",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-13 09:53:30",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-13 10:07:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 09:57:09",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-13 09:57:11",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347052846114426881",
              "tweetText" : "마침내 손에 넣은 아름답고 강력한 힘.\n당신의 든든한 조력자 스타더스트를 지금 만나보세요.\n\n마비노기 스타더스트 업데이트\n\n자세히 알아보기 ▶ https://t.co/SqHb3TOsYv https://t.co/bQ3a6eZMec",
              "urls" : [ "https://t.co/SqHb3TOsYv" ],
              "mediaUrls" : [ "https://t.co/bQ3a6eZMec" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-13 07:15:55"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 07:16:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 07:15:57",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-13 07:15:56",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1348555245828284419",
              "tweetText" : "[#빅톤]\nVICTON 1ST FULL ALBUM\n[VOICE : The future is now]\n'What I Said' Music Video🦋🪞✨\n\n📺 https://t.co/Y2geD8xsjE\n\n#VICTON #VOICE_The_future_is_now\n#What_I_Said\n#빅톤_What_I_Said https://t.co/8IHMByEoUa",
              "urls" : [ "https://t.co/Y2geD8xsjE" ],
              "mediaUrls" : [ "https://t.co/8IHMByEoUa" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "77415",
              "name" : "#빅톤_What_I_Said",
              "description" : "붐~붐~붐~와다쌛❗️붐~붐~VICTON의 와다쌛✨"
            },
            "advertiserInfo" : {
              "advertiserName" : "VICTON(빅톤)",
              "screenName" : "@VICTON1109"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-13 07:15:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 07:16:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 07:40:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 07:15:08",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-13 07:40:11",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-13 07:15:06",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340988962366607361",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "breads"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-13 06:25:21"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 06:25:24",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-13 07:04:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 06:25:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-13 07:16:57",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1348971181366538245",
              "tweetText" : "Your move and groove is about to get even more epic #withGalaxy. #SamsungUnpacked   on January 14, 2021. Find out more at https://t.co/D6nxwskptt https://t.co/58TnJkg4aD",
              "urls" : [ "https://t.co/D6nxwskptt" ],
              "mediaUrls" : [ "https://t.co/58TnJkg4aD" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76967",
              "name" : "#SamsungMobile20210114",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Samsung Mobile",
              "screenName" : "@SamsungMobile"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-14 01:23:32"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 01:29:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 01:24:33",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-14 01:23:38",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-14 01:24:26",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-14 01:24:29",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-14 01:31:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 01:24:34",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-14 01:24:31",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-14 01:24:34",
            "engagementType" : "VideoContentPlaybackComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347045296514195457",
              "tweetText" : "전장을 지배할 아름다운 별빛.\n선택받은 자에게만 주어지는 별의 힘을\n지금 바로 경험하세요\n\n마비노기 스타더스트 업데이트\n\n지금 알아보기▶https://t.co/sDU278bfOV https://t.co/yHVdM6EshX",
              "urls" : [ "https://t.co/sDU278bfOV" ],
              "mediaUrls" : [ "https://t.co/yHVdM6EshX" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-14 01:23:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 01:23:42",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347045296514195457",
              "tweetText" : "전장을 지배할 아름다운 별빛.\n선택받은 자에게만 주어지는 별의 힘을\n지금 바로 경험하세요\n\n마비노기 스타더스트 업데이트\n\n지금 알아보기▶https://t.co/sDU278bfOV https://t.co/yHVdM6EshX",
              "urls" : [ "https://t.co/sDU278bfOV" ],
              "mediaUrls" : [ "https://t.co/yHVdM6EshX" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-14 09:13:45"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 09:13:46",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911440362782720",
              "tweetText" : "덤벙도 오케이. 첨벙도 오케이. iPhone12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "breads"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-14 09:13:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 09:18:18",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-14 09:13:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 09:13:26",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-14 09:13:37",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-14 09:18:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 09:13:49",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-14 09:13:36",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-14 09:52:50",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 09:13:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 09:18:18",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-14 23:13:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 09:18:18",
            "engagementType" : "VideoContentPlaybackComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911362491392009",
              "tweetText" : "덤벙도 오케이. 첨벙도 오케이. iPhone12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765382"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765330"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765358"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765341"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765350"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-14 06:27:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 09:13:41",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-14 09:13:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-14 09:13:40",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-14 09:13:45",
            "engagementType" : "VideoContentPlayback50"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "Spotlight",
            "promotedTrendInfo" : {
              "trendId" : "77467",
              "name" : "#갤럭시스테이지 ",
              "description" : "1월 16일 오후9시  "
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "impressionTime" : "2021-01-14 23:20:26"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 23:20:26",
            "engagementType" : "SpotlightView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347052846114426881",
              "tweetText" : "마침내 손에 넣은 아름답고 강력한 힘.\n당신의 든든한 조력자 스타더스트를 지금 만나보세요.\n\n마비노기 스타더스트 업데이트\n\n자세히 알아보기 ▶ https://t.co/SqHb3TOsYv https://t.co/bQ3a6eZMec",
              "urls" : [ "https://t.co/SqHb3TOsYv" ],
              "mediaUrls" : [ "https://t.co/bQ3a6eZMec" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-14 23:09:20"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-14 23:09:22",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1344177085418332160",
              "tweetText" : "집사야 이사는 짐싸다냥",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "짐싸",
              "screenName" : "@zimssa24"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "25 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-17 16:52:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-17 16:53:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-17 16:52:59",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2021-01-17 16:52:59",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-17 16:53:02",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1350090029876486145",
              "tweetText" : "#GalaxyS21 #Samsung 🎉두근두근. 우리를 설레게 할 갤럭시 S21 TV광고 3편 중, 마음에 드는 광고를 필수 해시태그와 함께 리트윗 해주세요.\n※ 총 50명을 추첨하여 스타벅스 기프티콘 증정! 🎁 (1.15~1.24)\n※ 참여방법을 포함한 자세한 내용은 스레드를 확인해주세요\n[TVC③ S펜 편 ] https://t.co/LOSYesQRaT",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/LOSYesQRaT" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-17 16:52:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-17 16:57:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-17 16:52:52",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-17 16:55:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-17 16:52:45",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-17 16:52:51",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-17 16:53:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-17 23:05:24",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1351007574771068930",
              "tweetText" : "#GalaxyS21 #Samsung 🎉  #이날치 와 #릴보이 가 최고의 스마트폰 갤럭시 S21을 만나다! 두근두근 언박싱 감상하고, 감상 후기를 필수 해시태그와 함께 리트윗 해주세요!\n※ 총 50명을 추첨하여 스타벅스 기프티콘 증정! 🎁(1.18~1.28)\n※ 참여방법을 포함한 자세한 내용은 스레드를 확인해주세요 https://t.co/zQ0qOtDAXc",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/zQ0qOtDAXc" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-19 03:35:32"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-19 03:35:33",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-19 03:40:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-19 04:24:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-19 04:25:27",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1351007574771068930",
              "tweetText" : "#GalaxyS21 #Samsung 🎉  #이날치 와 #릴보이 가 최고의 스마트폰 갤럭시 S21을 만나다! 두근두근 언박싱 감상하고, 감상 후기를 필수 해시태그와 함께 리트윗 해주세요!\n※ 총 50명을 추첨하여 스타벅스 기프티콘 증정! 🎁(1.18~1.28)\n※ 참여방법을 포함한 자세한 내용은 스레드를 확인해주세요 https://t.co/zQ0qOtDAXc",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/zQ0qOtDAXc" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-18 23:07:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-18 23:07:24",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-18 23:10:13",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1349902418218127368",
              "tweetText" : "어떤 위협도 내 모험을 막지 못해!\n고대 힘이 깃든 활의 주인 패스파인더와\n떠나는 가슴 설레는 모험의 시작 🧭\n\n#메이플스토리M #신규캐릭터 #패스파인더",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리M",
              "screenName" : "@MapleStoryM_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의 집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#꿈의집"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-19 04:24:07"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-19 05:08:02",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-19 05:03:35",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-19 04:50:31",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-19 04:25:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-19 04:50:40",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-19 04:24:11",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-19 04:24:37",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-19 04:25:19",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-19 04:24:14",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Desktop"
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1351457088115859457",
              "tweetText" : "[#This_is_트레저_이펙트]\n\n안되면 어때 ↗️  다시 시작해 ↗️ \nYou’re the only one TREASURE -💎\n‘MY TREASURE’ 확인하러 고고 👇\n\n#TREASURE ‘MY TREASURE’ M/V\n🎬 https://t.co/cI1PqFQCWs\n\n#트레저 #1stALBUM #THEFIRSTSTEP_TREASUREEFFECT #MYTREASURE #MV #YG https://t.co/GFvabdij8U",
              "urls" : [ "https://t.co/cI1PqFQCWs" ],
              "mediaUrls" : [ "https://t.co/GFvabdij8U" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "77517",
              "name" : "#ygentofficial20210120",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "YG FAMILY",
              "screenName" : "@ygent_official"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-19 17:13:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-19 17:13:06",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-19 17:13:11",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "SearchTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1349144153393934339",
              "tweetText" : "[2021 새해 이벤트]\n2021년 새롭게 다짐한 올해의 목표는 무엇인가요? 몬스터 에너지 이벤트에 새해 목표를 적어서 응모하고 한정수량으로 제작한 몬스터 에너지 2021 플래너와 캘린더, 그리고 몬스터 에너지 1박스로 선물로 받아보세요! 이벤트 응모 바로가기👉 https://t.co/NyiMtLK8rZ https://t.co/byy2R8xBU2",
              "urls" : [ "https://t.co/NyiMtLK8rZ" ],
              "mediaUrls" : [ "https://t.co/byy2R8xBU2" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-20 23:22:19"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-20 23:22:21",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1349575220009472000",
              "tweetText" : "연말을 불태우는 아이돌 팬들의 진검승부, “시상식 인기 투표”를 알아보자\n\n기사 보러가기 👇\nhttps://t.co/dg5sbm2OtK",
              "urls" : [ "https://t.co/dg5sbm2OtK" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#공연"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "여자친구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#제니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이유(Iu) 공식 트위터"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#여자친구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#지민"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#라디오"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "제니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Jang Keun Suk 장근석"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지민"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라디오"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#음악추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "슈가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "공연"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#슈가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "한국어 노래"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "RM"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "j-hope"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Jungkook"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "K-pop"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Jimin"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Jin"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "V (BTS)"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "SUGA"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Music festivals and concerts"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-20 23:15:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-20 23:15:12",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1351007574771068930",
              "tweetText" : "#GalaxyS21 #Samsung 🎉  #이날치 와 #릴보이 가 최고의 스마트폰 갤럭시 S21을 만나다! 두근두근 언박싱 감상하고, 감상 후기를 필수 해시태그와 함께 리트윗 해주세요!\n※ 총 50명을 추첨하여 스타벅스 기프티콘 증정! 🎁(1.18~1.28)\n※ 참여방법을 포함한 자세한 내용은 스레드를 확인해주세요 https://t.co/zQ0qOtDAXc",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/zQ0qOtDAXc" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-21 10:05:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-21 10:09:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-21 10:14:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-21 10:06:36",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-21 10:08:37",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321415248776056832",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. Apple Pencil 하나면 필기는 물론 일러스트 작업, 주석 추가까지 가능하죠. *Apple Pencil은 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "macos"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-09 18:10:59"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-10 02:27:32",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-10 02:28:19",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1351007574771068930",
              "tweetText" : "#GalaxyS21 #Samsung 🎉  #이날치 와 #릴보이 가 최고의 스마트폰 갤럭시 S21을 만나다! 두근두근 언박싱 감상하고, 감상 후기를 필수 해시태그와 함께 리트윗 해주세요!\n※ 총 50명을 추첨하여 스타벅스 기프티콘 증정! 🎁(1.18~1.28)\n※ 참여방법을 포함한 자세한 내용은 스레드를 확인해주세요 https://t.co/zQ0qOtDAXc",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/zQ0qOtDAXc" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-22 06:41:06"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-22 06:41:08",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-22 06:42:26",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1351007574771068930",
              "tweetText" : "#GalaxyS21 #Samsung 🎉  #이날치 와 #릴보이 가 최고의 스마트폰 갤럭시 S21을 만나다! 두근두근 언박싱 감상하고, 감상 후기를 필수 해시태그와 함께 리트윗 해주세요!\n※ 총 50명을 추첨하여 스타벅스 기프티콘 증정! 🎁(1.18~1.28)\n※ 참여방법을 포함한 자세한 내용은 스레드를 확인해주세요 https://t.co/zQ0qOtDAXc",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/zQ0qOtDAXc" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-22 04:22:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-22 04:24:20",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2021-01-22 04:24:14",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-22 04:24:20",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-22 04:24:20",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2021-01-22 04:24:31",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-22 04:24:18",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-22 04:26:24",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-22 04:24:16",
            "engagementType" : "VideoContentMrcView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1351843858053804032",
              "tweetText" : "Welcome to Qatar, the home of our state-of-the-art Hamad International Airport. Where renowned hospitality meets the highest standards in safety.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Qatar Airways",
              "screenName" : "@qatarairways"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Travel"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-22 04:22:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-22 04:26:24",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-22 04:24:50",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2021-01-22 04:24:51",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339159246504513537",
              "tweetText" : "대망의 앙상블스타즈!!가 새롭게 돌아왔습니다.\n아이돌을 육성하는 즐거움을 만끽해보세요!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "앙상블스타즈!!",
              "screenName" : "@enstars2_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "게임 메이커"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "숨겨진 개체 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "카드 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "한게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#컴퓨터게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "개인용 컴퓨터 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "안드로이드 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Animation"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#한게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모험 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Series"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모바일 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Movies"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Best Mangas"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Top Animes"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#모바일게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "무료 플레이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Shows"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#슈팅게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "온라인 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Show"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Best Animes"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "WiFi only targeting",
              "targetingValue" : "WiFi-only"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-23 02:28:36"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-23 02:30:57",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-23 02:32:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-23 02:30:35",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-23 02:30:33",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-23 02:31:04",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-23 02:30:50",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-23 02:31:03",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-23 02:30:42",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-23 02:30:49",
            "engagementType" : "VideoContentPlayback50"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1353354368616177664",
              "tweetText" : "골든차일드 다섯번째 미니앨범\n'안아줄게(Burn It)'\n\n니가 좀비가 되어도,\n너의 모든 아픔, 슬픔까지\n안아줄게\n\n🎵 2021. 01. 25. 6PM (KST)\n\n#GoldenChild #골든차일드 #YES\n#안아줄게 #Burn_It #좀비\n@GoldenChild https://t.co/RaoGqGMGbi",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/RaoGqGMGbi" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "77530",
              "name" : "#GoldenChild20210125",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "GoldenChild (골든차일드)",
              "screenName" : "@GoldenChild"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-24 17:00:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-24 17:04:19",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-24 17:00:12",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-24 17:10:19",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1353632715959005190",
              "tweetText" : "Check out Bobby’s 2nd FULL ALBUM [LUCKY MAN]. \nTitle song &lt;U Mad&gt; out now 🔥🔥🔥",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "K-POP AD 남일애드컴 南艺企划",
              "screenName" : "@k_pop_ad"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-25 11:53:03"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-25 11:53:04",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1352437254292029441",
              "tweetText" : "[외교부 업무보고]\n2021년 외교부는 모든 국민들이 더 나은 일상을 누리는 평화로운 한반도를 실현하고, 국민과 함께 도약하는 경제외교를 전개하겠습니다.\n\n자세히 보기&gt; https://t.co/qjD0pmpwE4\n\n#외교부 #2021외교부업무보고 https://t.co/hmPSEN1kcJ",
              "urls" : [ "https://t.co/qjD0pmpwE4" ],
              "mediaUrls" : [ "https://t.co/hmPSEN1kcJ" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "외교부",
              "screenName" : "@mofa_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-26 16:22:10"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-26 16:22:10",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1336271473107824641",
              "tweetText" : "함께 달릴 쿠키가 필요해? 🤔\n지금 접속하면 5일간 5종의 에픽 쿠키를 드려요!\n쿠키 걱정 없이 지금 바로 플레이 ❤️\n\n#쿠키런 #쿠키런오븐브레이크",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런 : 오븐브레이크",
              "screenName" : "@CookieRunKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "넥슨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿀잼"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니팡"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이러브커피"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모바일게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다운로드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "배린이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "넷마블"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "앱스토어"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 8.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-26 16:22:07"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-26 21:43:32",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-26 16:55:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-26 16:22:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-26 16:36:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-26 23:39:02",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-26 16:36:16",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-26 16:55:29",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-26 16:22:16",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-26 16:38:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-26 16:34:53",
            "engagementType" : "VideoContentPlayback25"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1352606351982096390",
              "tweetText" : "킹킹킹덤 킹킹덤 킹덤킹덤 쿠키런킹덤~🎶👑\n축하합니다🙌 당신은 이 노래에 중독되었습니다.\n\n쿠키런 소셜 RPG 쿠키런: 킹덤, 출시하자마자 100만 다운로드 돌파! \n개성만점 쿠키들과 새로운 모험을 떠나보세요!\n\n#쿠키런킹덤",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런: 킹덤",
              "screenName" : "@CRKingdomKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더보이즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "발매"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "빌보드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 13.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom IOS All"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "사전예약완료"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-27 10:10:02"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-27 10:10:11",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-27 10:10:26",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-27 10:28:40",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 10:10:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 10:10:32",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-27 10:10:19",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-27 10:10:04",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-27 10:10:18",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-27 10:10:33",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-27 10:28:02",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 10:33:17",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1352606351982096390",
              "tweetText" : "킹킹킹덤 킹킹덤 킹덤킹덤 쿠키런킹덤~🎶👑\n축하합니다🙌 당신은 이 노래에 중독되었습니다.\n\n쿠키런 소셜 RPG 쿠키런: 킹덤, 출시하자마자 100만 다운로드 돌파! \n개성만점 쿠키들과 새로운 모험을 떠나보세요!\n\n#쿠키런킹덤",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런: 킹덤",
              "screenName" : "@CRKingdomKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더보이즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "빌보드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "발매"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 13.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom IOS All"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "사전예약완료"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-27 06:21:46"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-27 07:27:06",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 06:32:59",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 07:21:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 06:22:25",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-27 06:22:27",
            "engagementType" : "VideoContentMrcView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1352606351982096390",
              "tweetText" : "킹킹킹덤 킹킹덤 킹덤킹덤 쿠키런킹덤~🎶👑\n축하합니다🙌 당신은 이 노래에 중독되었습니다.\n\n쿠키런 소셜 RPG 쿠키런: 킹덤, 출시하자마자 100만 다운로드 돌파! \n개성만점 쿠키들과 새로운 모험을 떠나보세요!\n\n#쿠키런킹덤",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런: 킹덤",
              "screenName" : "@CRKingdomKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "빌보드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "발매"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더보이즈"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 13.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom IOS All"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "사전예약완료"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-27 08:24:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-27 08:28:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 08:24:21",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 09:26:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 08:24:14",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1352606351982096390",
              "tweetText" : "킹킹킹덤 킹킹덤 킹덤킹덤 쿠키런킹덤~🎶👑\n축하합니다🙌 당신은 이 노래에 중독되었습니다.\n\n쿠키런 소셜 RPG 쿠키런: 킹덤, 출시하자마자 100만 다운로드 돌파! \n개성만점 쿠키들과 새로운 모험을 떠나보세요!\n\n#쿠키런킹덤",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런: 킹덤",
              "screenName" : "@CRKingdomKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "빌보드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라디오"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더보이즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "기현"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "발매"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 13.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: Kingdom IOS All"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "사전예약완료"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-27 16:41:27"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-27 23:06:29",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-27 23:06:25",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-27 23:06:24",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-27 23:08:33",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-27 23:06:26",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2021-01-27 23:06:26",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2021-01-27 23:06:23",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-27 23:06:30",
            "engagementType" : "VideoContentPlayback25"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1336271473107824641",
              "tweetText" : "함께 달릴 쿠키가 필요해? 🤔\n지금 접속하면 5일간 5종의 에픽 쿠키를 드려요!\n쿠키 걱정 없이 지금 바로 플레이 ❤️\n\n#쿠키런 #쿠키런오븐브레이크",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런 : 오븐브레이크",
              "screenName" : "@CookieRunKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "넷마블"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모바일게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마인크래프트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다운로드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니팡"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "넥슨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿀잼"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이러브커피"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "배린이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "앱스토어"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 8.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-28 16:26:46"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-28 16:34:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-28 23:21:50",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-28 16:26:47",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-28 16:40:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-28 16:27:20",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-28 16:30:20",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-28 16:26:49",
            "engagementType" : "VideoContentPlayback25"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Desktop"
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326025506978848769",
              "tweetText" : "여자친구 (GFRIEND) 回:Walpurgis Night\n\n‘MAGO’ Official M/V\nhttps://t.co/b676oO186g  \n\n#여자친구 #GFRIEND #MAGO #여자친구_MAGO_마고_기대해 #마고많관부 https://t.co/0JsO0nnRik",
              "urls" : [ "https://t.co/b676oO186g" ],
              "mediaUrls" : [ "https://t.co/0JsO0nnRik" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76028",
              "name" : "#여자친구_MAGO_마고_기대해",
              "description" : "빗자룰💜타고서💙여친과🤍날아가_MAGO "
            },
            "advertiserInfo" : {
              "advertiserName" : "여자친구 GFRIEND",
              "screenName" : "@GFRDofficial"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-11 05:52:19"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-11 05:52:24",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-11 05:52:36",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-11 05:52:22",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-11 05:52:41",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-11 05:52:36",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-11 05:52:21",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-11 05:52:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-11 05:52:24",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-11 05:52:31",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-11 05:52:40",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-11 05:52:26",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-11 05:52:27",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-11 05:52:23",
            "engagementType" : "VideoContentMrcView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010652349657088",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-11 18:48:51"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-11 18:49:43",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-11 18:52:57",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-11 18:49:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-11 18:52:57",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-11 18:49:15",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-11 18:52:54",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-11 18:52:50",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-11 18:56:11",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010652349657088",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-11 18:48:51"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 00:17:35",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1323527809751396352",
              "tweetText" : "탕수육은 당연히 찍먹 아닌가요?\n부먹파들은 로션도 부어 바른다면서요?👀\n트친님의 의견을 스푼에서 알려주세요!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Spoon Korea",
              "screenName" : "@spoon__korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 11.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Spoon | Audio Live Streaming IOS All"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-12 00:16:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 00:19:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 00:17:59",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326090691747827713",
              "tweetText" : "11월 19일은 #VansCheckerboardDay 창의적인 움직임에 참여해 보세요.\nhttps://t.co/rHCMlh5U9G https://t.co/hh0AWJSorE",
              "urls" : [ "https://t.co/rHCMlh5U9G" ],
              "mediaUrls" : [ "https://t.co/hh0AWJSorE" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Vans Korea",
              "screenName" : "@korea_vans"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-12 00:16:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 00:18:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 00:18:12",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-12 00:18:12",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326540191968997376",
              "tweetText" : "#유니버스로_사라진_아티스트 🪐\n\n🎳🐰🥤👟...?! “우리가 누구?”\n\n오늘 오전 10시, #유니버스 #사전예약 시작과 함께 유니버스로 사라진 아티스트가 공개됩니다!\n\n▶️https://t.co/cFwrEd9lgv\n\n#유니버스 #UNIVERSE #1SecToArtist #Into__UNIVERSE #유니버스_사전예약 #UNIVERSE_Preregistration https://t.co/irmbWWcOYr",
              "urls" : [ "https://t.co/cFwrEd9lgv" ],
              "mediaUrls" : [ "https://t.co/irmbWWcOYr" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75543",
              "name" : "#웰컴투_아이즈원_유니버스",
              "description" : "아이아이 아이즈원입니다!❤ 우리 유니버스에서 더 가까워져요! 사전예약 👉universe-official.io"
            },
            "advertiserInfo" : {
              "advertiserName" : "UNIVERSE_OFFICIAL",
              "screenName" : "@into__universe"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-12 00:16:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 00:17:33",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-12 00:17:34",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-12 00:18:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 00:17:35",
            "engagementType" : "VideoContentMrcView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010846512340997",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 사진"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "우 만다"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-12 04:37:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 04:42:18",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-12 04:42:17",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-12 04:42:19",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 04:42:15",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-12 10:31:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 04:39:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 04:42:18",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-12 04:39:48",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-12 04:42:16",
            "engagementType" : "VideoContentMrcView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326503120524902400",
              "tweetText" : "혹시 #난시?😩\n이리보고 요리보고 저리보고 흔들려도 #또렷\n#난시엔 #아큐브오아시스💙\n\n📌 마이아큐브에서 첫구매 쿠폰받아요\n#최대4만원_할인\n#카카오_이모티콘\n#스타벅스_기프티콘 (선착순)\n\n#아큐브 #난시렌즈 #난시또렷👍🏻\n의료기기 광고심의필 2020-T10-32-0340, KR_2020_543",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76162",
              "name" : "#AcuvueKorea20201113",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "ACUVUE Korea",
              "screenName" : "@AcuvueKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-12 19:14:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-13 03:15:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-13 03:37:45",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-13 02:35:07",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326486303492464640",
              "tweetText" : "오는 금요일 출시\n\n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Rainbow Six Siege"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Overwatch"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Destiny"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-12 19:14:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 19:22:13",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-12 19:22:21",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326503120524902400",
              "tweetText" : "혹시 #난시?😩\n이리보고 요리보고 저리보고 흔들려도 #또렷\n#난시엔 #아큐브오아시스💙\n\n📌 마이아큐브에서 첫구매 쿠폰받아요\n#최대4만원_할인\n#카카오_이모티콘\n#스타벅스_기프티콘 (선착순)\n\n#아큐브 #난시렌즈 #난시또렷👍🏻\n의료기기 광고심의필 2020-T10-32-0340, KR_2020_543",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76162",
              "name" : "#AcuvueKorea20201113",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "ACUVUE Korea",
              "screenName" : "@AcuvueKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-12 19:14:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-12 19:22:21",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 19:20:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 19:19:43",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-12 19:14:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-12 19:19:35",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-12 19:19:39",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-12 19:16:18",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-12 19:14:30",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-12 19:16:09",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-12 19:19:36",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-12 19:35:57",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1320609430258417664",
              "tweetText" : "새롭게 선보이는 iPhone 12 Pro. 5G로 만나는 첫 iPhone, 그 강력한 속도를 경험하세요.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-13 03:43:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-13 17:29:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-13 03:43:18",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-13 03:43:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-13 03:43:20",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-13 03:43:25",
            "engagementType" : "VideoContentPlayback50"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326502915486306306",
              "tweetText" : "혹시 #난시?😩\n이리보고 요리보고 저리보고 흔들려도 #또렷\n#난시엔 #아큐브오아시스💙\n\n📌 마이아큐브에서 첫구매 쿠폰받아요\n#최대4만원_할인\n#카카오_이모티콘\n#스타벅스_기프티콘 (선착순)\n\n#아큐브 #난시렌즈 #난시또렷👍🏻\n의료기기 광고심의필 2020-T10-32-0341, KR_2020_543",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76163",
              "name" : "#AcuvueKorea20201114",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "ACUVUE Korea",
              "screenName" : "@AcuvueKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-13 17:28:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-13 17:29:50",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-13 17:29:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-13 17:29:05",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-13 17:32:33",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010846512340997",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 사진"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "우 만다"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-14 05:14:39"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-14 17:33:08",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Desktop"
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326045793992667136",
              "tweetText" : "쌍둥이 형제 이현과 이찬. 재민은 그들이 짜놓은 덫에 걸린 것도 모르고 성실하게 일하지만, 곧 무언가 잘못되었다는 것을 깨닫게 된다.\n\n“집에 갈래요. 보내주세요.”\n \n[클랩] ⓒ할로윈\n무료회차 보러가기 ▶https://t.co/KGqjq11o8R\n \n#BL #봄소설 #오메가버스 #집착공 #SM #감금 https://t.co/kVc76joAtg",
              "urls" : [ "https://t.co/KGqjq11o8R" ],
              "mediaUrls" : [ "https://t.co/kVc76joAtg" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "봄툰_봄소설추천봇",
              "screenName" : "@BOM_NOVEL"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "개아가수"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "사랑"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "친구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마조"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게이"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "클랩 조회자"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-14 16:52:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-14 16:54:10",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-14 16:52:57",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-14 16:53:44",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-14 16:52:53",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-14 16:52:51",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-14 16:54:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-14 16:54:37",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-14 16:54:32",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-14 16:53:17",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-14 16:53:06",
            "engagementType" : "VideoContentShortFormComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010688026337280",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24319974"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528380"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24319966"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24272691"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24319957"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528439"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528293"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528394"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24366135"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-14 18:56:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 01:44:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 01:43:20",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-15 01:43:19",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010688026337280",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24319974"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528380"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24319966"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24272691"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24319957"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528439"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528293"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528394"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24366135"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-14 17:33:08"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-14 17:37:46",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-14 17:43:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-14 17:33:11",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321415197370716162",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. Apple Pencil 하나면 필기는 물론 일러스트 작업, 주석 추가까지 가능하죠. *Apple Pencil은 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "우 만다"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 사진"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-15 01:42:35"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 01:53:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 01:44:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 01:42:38",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 01:43:23",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-15 01:49:11",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-15 01:56:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 01:49:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 01:54:06",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1306804368578981889",
              "tweetText" : "\"형님과 몸을 섞은 음인을 형수라 하지 않으면, 뭐라 불러야 하는지. 하하.\"\n\n음인인 기조는 황제에게 접객소의 노예를 취급받고 있는 와중에, 친왕은 그런 기조에게 '형수'라 부르며 조롱하는데..\n\n[나선몽] ⓒ ice\n무료회차 보러가기 ▶️ https://t.co/cnSOpnJu2e\n\n#BL #오메가버스 #집착공 #황제공 https://t.co/6CGsnwUCxh",
              "urls" : [ "https://t.co/cnSOpnJu2e" ],
              "mediaUrls" : [ "https://t.co/6CGsnwUCxh" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "봄툰_봄소설추천봇",
              "screenName" : "@BOM_NOVEL"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "신음"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "집착"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "19금만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "완결"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "놀이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고수위"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "자위"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "봄툰"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "나선몽 조회자"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-15 01:42:35"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 01:42:48",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-15 01:43:10",
            "engagementType" : "Detail"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1326796877010890752",
              "tweetText" : "좋은 리더가 팀에 미치는 영향\n\nTalk 10. 토스의 리더: 지금의 리더가 해야할 일\n\n풀버전 영상 보러가기\n=&gt; https://t.co/00m1UUozMA\n\n일에 대하여, theWORK\nOriginal Content by Toss",
              "urls" : [ "https://t.co/00m1UUozMA" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "토스",
              "screenName" : "@Toss_service"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "브랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "재테크"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-15 14:16:51"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 14:34:18",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326567547332927489",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Rainbow Six Siege"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Destiny"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Overwatch"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-15 14:34:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 14:37:33",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 14:48:00",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-15 14:48:01",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-15 15:03:36",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326567547332927489",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Destiny"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Rainbow Six Siege"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Overwatch"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-15 13:12:30"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 13:25:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 13:27:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 13:25:40",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-15 13:19:20",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 13:25:49",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-15 13:25:40",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1319442189391335429",
              "tweetText" : "혜솔 성림에게 길들여져버린 그 남자의 ♨️뒤 사정♨️\n\n여공남수 캠퍼스 로맨스 \n&lt;2차선 도로 터널 뚫기&gt;\n\n웹툰 바로보기 👉 https://t.co/Bwnf1rydjA https://t.co/4ByAiLiyBq",
              "urls" : [ "https://t.co/Bwnf1rydjA" ],
              "mediaUrls" : [ "https://t.co/4ByAiLiyBq", "https://t.co/4ByAiLiyBq", "https://t.co/4ByAiLiyBq", "https://t.co/4ByAiLiyBq" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "레진코믹스",
              "screenName" : "@LezhinComics"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "성인만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "패션"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "봄툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "왜하면안돼"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미스터블루"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "탑툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "네이버웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "저스툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "왓챠"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "코믹스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더쿠"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엄마의남자"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림러"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "로맨스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "넷플릭스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다음웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "캐릭터"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고수위"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "입술"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-15 09:02:51"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 09:58:14",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-15 09:58:22",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-15 09:58:12",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-15 09:58:26",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-15 09:58:23",
            "engagementType" : "EmbeddedMedia"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1320595353767268352",
              "tweetText" : "새롭게 선보이는 iPhone 12 Pro. 정밀 가공된 고강도 스테인리스 스틸의 독보적 디자인. 새로운 퍼시픽 블루 컬러와 두 가지 크기, 네 가지 마감의 다양함을 만나보세요.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-15 08:05:14"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 08:41:08",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-15 08:05:17",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 08:05:18",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-15 08:41:02",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-15 08:41:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 08:08:39",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326567547332927489",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Destiny"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Overwatch"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Rainbow Six Siege"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-15 08:33:18"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 08:41:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 08:39:19",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327778341936623616",
              "tweetText" : "#유니버스 의 #강다니엘 플래닛 OPEN!🛸\n\n강다니엘이 자세히 설명해주는 단서들을 확인하고 유니버스 사전예약하세요!\n\n#웰컴투_강다니엘_유니버스 💫\n▶️https://t.co/cFwrEd9lgv\n\n#UNIVERSE #1SecToArtist #Into__UNIVERSE #강다니엘_Planet #유니버스_사전예약 @konnect_danielk https://t.co/DIfbL9Cq0B",
              "urls" : [ "https://t.co/cFwrEd9lgv" ],
              "mediaUrls" : [ "https://t.co/DIfbL9Cq0B" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75546",
              "name" : "#웰컴투_강다니엘_유니버스",
              "description" : "다니티 '뭐해'🎵요? 유니버스 사전예약하고 응모권 받으러 고고! 👉universe-official.io"
            },
            "advertiserInfo" : {
              "advertiserName" : "UNIVERSE_OFFICIAL",
              "screenName" : "@into__universe"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-15 08:51:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 09:12:58",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 09:01:28",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-15 10:00:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 08:57:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 09:01:42",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-15 09:01:29",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-15 09:01:28",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-15 09:01:28",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-15 08:56:00",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 09:01:26",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-15 09:01:41",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-15 08:56:01",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-15 09:01:33",
            "engagementType" : "VideoContentPlayback50"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326567547332927489",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Xbox"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Nintendo"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-15 11:50:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 12:06:44",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:53:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:56:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:50:18",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 11:57:09",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010743324078082",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-15 11:05:13"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 11:10:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:12:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:08:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:06:59",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 11:05:55",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010883367735296",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "애니"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-15 12:28:19"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 12:38:42",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-15 12:28:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 12:28:21",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 12:39:32",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "advertiserInfo" : {
              "advertiserName" : "샤이닝니키",
              "screenName" : "@ShiningNikki_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "webcomic"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "연하공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "레진코믹스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "네이버웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다음웹툰"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install 샤이닝니키 IOS All"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-03 17:16:18"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-03 17:17:21",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-03 17:17:23",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "advertiserInfo" : {
              "advertiserName" : "샤이닝니키",
              "screenName" : "@ShiningNikki_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "webcomic"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "연하공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "레진코믹스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "네이버웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다음웹툰"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install 샤이닝니키 IOS All"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-03 17:16:18"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-04 06:58:20",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322070736270323713",
              "tweetText" : "새롭게 선보이는 MagSafe. 내장 자석이 있어 액세서리 부착은 더 쉬워지고, 무선 충전은 더 빨라졌죠.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-16 02:34:58"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-16 02:38:36",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-16 02:38:36",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-16 02:38:36",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-16 02:38:30",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-16 03:30:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 02:38:35",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-16 02:38:37",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-16 02:38:35",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-16 02:38:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 02:36:22",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 02:38:36",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-16 03:26:11",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 02:35:55",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-16 02:38:37",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-16 02:50:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 02:38:34",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-16 03:27:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 02:38:13",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-16 02:38:44",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 03:23:10",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321349007856128001",
              "tweetText" : "2022 0원 메가패스 30초 버전 영상 공개🎬\n\n친구들이랑 놀고, 운동도 하고…\n그래도 공부는 계속 해야하니까 😏⠀\n\n합격, 그 이상의 나를 완성해봐! \nComplete me 메가패스\n\n𝘄𝗶𝘁𝗵 𝗺𝗲𝗴𝗮𝘀𝘁𝘂𝗱𝘆 \n#메가스터디 #합격불변의법칙 #2022메가패스 #20220원메가패스 #모델이도현 #이도현",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "메가스터디",
              "screenName" : "@theMEGASTUDY"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "대학"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "수능"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고2"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고등학생"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "공부"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고3"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "13 to 24"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-15 22:57:20"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 22:57:42",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-15 22:58:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 22:57:43",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-15 22:57:44",
            "engagementType" : "VideoContentMrcView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327989735017512961",
              "tweetText" : "#유니버스로_사라진_아티스트 🪐\n \n보라색 장미💜🌹?!\n🐩🐕👑🍒🍊👗…?!! \n \n오늘 오전 10시, 사라진 아티스트를 유니버스에서 만나보세요.\n\n#지금_유니버스_사전예약중\n▶️https://t.co/cFwrEdqW83\n \n#유니버스 #UNIVERSE #1SecToArtist #Into__UNIVERSE #유니버스_사전예약 #UNIVERSE_Preregistration https://t.co/P50lcnXGq2",
              "urls" : [ "https://t.co/cFwrEdqW83" ],
              "mediaUrls" : [ "https://t.co/P50lcnXGq2" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75547",
              "name" : "#웰컴투_여자아이들_유니버스",
              "description" : "🐩🐕💬 (여자)아이들 플래닛 공개! 유니버스에서 사전예약하고 응모권🎫 받고! 👉universe-official.io"
            },
            "advertiserInfo" : {
              "advertiserName" : "UNIVERSE_OFFICIAL",
              "screenName" : "@into__universe"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-15 16:04:47"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-15 16:08:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 16:06:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-15 16:04:50",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1327152118017486851",
              "tweetText" : "\"아직 참여하지 않은 학교 어디~?\"\n#더보이즈 와 함께하는 #신생아살리기캠페인 시즌14\n\n지금 #스쿨키트 신청하고\n#우리학교도함께해요 해시태그와 함께 인증하면\n선물이~🎁\n\n참여는 인스타그램에서! https://t.co/VRCSMTLvPN\n\n#세이브더칠드런 #THEBOYZ #모자뜨기 https://t.co/KxQOXLOyKK",
              "urls" : [ "https://t.co/VRCSMTLvPN" ],
              "mediaUrls" : [ "https://t.co/KxQOXLOyKK" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "세이브더칠드런",
              "screenName" : "@stckorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "13 to 24"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-16 04:24:50"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-16 04:25:17",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-16 04:25:18",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-16 04:24:56",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-16 04:25:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 04:25:16",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-16 04:28:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 04:25:14",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-16 04:25:15",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-16 04:25:16",
            "engagementType" : "VideoContentViewV2"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010846512340997",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 사진"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "우 만다"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "셀카"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-16 10:27:33"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-16 10:28:17",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-16 16:08:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 10:29:05",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-16 10:29:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 10:28:20",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-16 10:28:14",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328352128293883905",
              "tweetText" : "#유니버스로_사라진_아티스트 🪐\n\n8개의 마이크🎤 M...a...k...e...s.... \n🏴‍☠️🔭🍎🍗..!!\n\n오늘 오전 10시, 사라진 아티스트를 확인하세요!\n\n#지금_유니버스_사전예약중\n▶️https://t.co/cFwrEd9lgv\n \n#유니버스 #UNIVERSE #1SecToArtist #Into__UNIVERSE #유니버스_사전예약 #UNIVERSE_Preregistration https://t.co/hFqMxItqER",
              "urls" : [ "https://t.co/cFwrEd9lgv" ],
              "mediaUrls" : [ "https://t.co/hFqMxItqER" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75548",
              "name" : "#웰컴투_ATEEZ_유니버스",
              "description" : "단서 찾아준 에이티니~ Thanxx! 🙏 ATEEZ 유니버스도 꼭 찾아줘! 사전예약 👉universe-official.io"
            },
            "advertiserInfo" : {
              "advertiserName" : "UNIVERSE_OFFICIAL",
              "screenName" : "@into__universe"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-16 16:05:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-16 16:08:22",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-16 16:08:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-16 16:08:18",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321415197370716162",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. Apple Pencil 하나면 필기는 물론 일러스트 작업, 주석 추가까지 가능하죠. *Apple Pencil은 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "셀카"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "우 만다"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 사진"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-17 04:24:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-17 05:23:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-17 05:21:54",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-17 05:21:57",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-17 05:21:57",
            "engagementType" : "VideoContent1secView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328617105386733568",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating, Make Friends and Meet New People ANDROID 7 Day"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-17 18:13:10"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-17 18:14:58",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-17 18:13:34",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-17 18:13:31",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321415162616664064",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. Apple Pencil 하나면 필기는 물론 일러스트 작업, 주석 추가까지 가능하죠. *Apple Pencil은 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "학생"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "대학교"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "대학생"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "학교"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "정도"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "대학"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "시험"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Education"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-17 18:13:10"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-17 18:13:28",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-17 21:45:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-17 18:13:27",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-17 18:14:41",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-17 22:20:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-17 18:14:41",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-17 18:14:33",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-17 18:14:33",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-17 18:14:33",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-17 18:14:33",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-17 18:14:58",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-17 18:14:34",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-17 18:14:37",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-17 18:13:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-17 18:14:40",
            "engagementType" : "VideoContentPlayback95"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322070736270323713",
              "tweetText" : "새롭게 선보이는 MagSafe. 내장 자석이 있어 액세서리 부착은 더 쉬워지고, 무선 충전은 더 빨라졌죠.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-18 05:42:23"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-18 05:42:46",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-18 05:42:35",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-18 05:42:34",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-18 05:45:55",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327455988652281856",
              "tweetText" : "기다려온 손맛 iPhone 12 mini. 기대되는 눈맛 iPhone Pro Max. 새로운 두 가지 사이즈, 지금 맛보러 가기.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "75744",
              "name" : "#Apple20201120",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-19 17:14:03"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-19 17:16:58",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-19 17:18:02",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-19 17:17:11",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-19 22:18:21",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-19 17:16:48",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-19 17:17:11",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-19 17:17:01",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-19 17:17:11",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-19 17:16:48",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328602228358262784",
              "tweetText" : "두근두근 펼쳐지는 판타지 매직, 블링블링 꾸며보는 스타일 매직! 마법 가득한 마술양품점에서 만나요♥\n#마술양품점 #다운로드 #꾸미고_싶은_매직",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마술양품점",
              "screenName" : "@MagicShop_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Girls' Generation"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더보이즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "ITZY"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "공연"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아지톡"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음방"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "기현"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "13 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-20 03:26:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-20 03:26:54",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-20 03:35:56",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1329784058172289025",
              "tweetText" : "완전히 달라진 메이플스토리M이 온다!\n귀여움이 쏟아지는 특별한 영상과 함께\n더 비기닝 사전등록 지금 바로 GO!❤\n\n#메이플스토리M_더비기닝 #사전등록",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76319",
              "name" : "#MapleStoryMKR20201121",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리M",
              "screenName" : "@MapleStoryM_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-21 13:47:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-21 18:50:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-21 18:44:27",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321408665471963136",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. 플로팅 디자인에 백라이트 키, 트랙패드가 탑재된 Magic Keyboard와 완벽한 조화를 이루죠. *Magic Keyboard는 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 사진"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "셀카"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "우 만다"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-22 02:21:52"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-22 02:23:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 02:21:59",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321408596265955328",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. 플로팅 디자인에 백라이트 키, 트랙패드가 탑재된 Magic Keyboard와 완벽한 조화를 이루죠. *Magic Keyboard는 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327401"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327375"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327414"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327279"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-22 23:13:38"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-23 04:46:09",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321408596265955328",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. 플로팅 디자인에 백라이트 키, 트랙패드가 탑재된 Magic Keyboard와 완벽한 조화를 이루죠. *Magic Keyboard는 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327401"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327375"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327414"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327279"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-22 23:13:38"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-22 23:21:59",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 23:13:40",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-22 23:21:58",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-22 23:20:04",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-22 23:24:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 23:20:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 23:18:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 23:13:44",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321403637524877318",
              "tweetText" : "새롭게 찾아온 iPad Air. 전면 화면 디자인에 번개처럼 빠른 속도의 A14 Bionic 칩 탑재. Magic Keyboard, Apple Pencil과의 완벽한 조화. 이 모든 걸 다채로운 매력의 다섯 가지 컬러로 만나보세요. *액세서리는 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-22 17:10:20"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-22 17:16:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 17:15:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-22 17:15:26",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-22 17:15:27",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-22 17:14:41",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-22 17:15:25",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-22 17:15:22",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-22 17:15:27",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-22 17:14:21",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-22 17:14:17",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1323553710618800129",
              "tweetText" : "5억불 수주를 위해 파라과이로 (외교부 외무사무관 브이로그)\n장기화되는 코로나19 상황... \n하지만 포기할 수 없는 대면외교 활동과 경제외교!\n5억불 규모 경전철 사업 수주를 위해 코로나19를 뚫고 파라과이로 날아간 민관합동대표단의 여정, 외교부 사무관 브이로그로 담았습니다. https://t.co/T49EXV8cFW",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/T49EXV8cFW" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "외교부",
              "screenName" : "@mofa_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-04 06:58:08"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-04 06:58:09",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-11-04 06:58:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-04 06:58:09",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321415162616664064",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. Apple Pencil 하나면 필기는 물론 일러스트 작업, 주석 추가까지 가능하죠. *Apple Pencil은 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Education"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "대학생"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-23 10:45:25"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-23 17:31:40",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-23 17:31:12",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1330798247732981762",
              "tweetText" : "GOT7 \"Breath (넌 날 숨 쉬게 해)\" M/V\nhttps://t.co/OMyZ9KwF1r\n\n2020.11.23 MON 6PM (KST)\n\n#GOT7 #갓세븐 \n#IGOT7 #아가새\n#GOT7_BreathofLove_LastPiece\n#GOT7_Breath\n#GOT7_LASTPIECE https://t.co/haKocFkPfx",
              "urls" : [ "https://t.co/OMyZ9KwF1r" ],
              "mediaUrls" : [ "https://t.co/haKocFkPfx" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76408",
              "name" : "#GOT7_Breath",
              "description" : "갓세븐 덕분에 숨 쉴 수 있잖아🌬 30일 6PM <Breath of Love : Last Piece> 발매까지 많관부🐥💚"
            },
            "advertiserInfo" : {
              "advertiserName" : "GOT7",
              "screenName" : "@GOT7Official"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-23 17:31:10"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-23 17:38:25",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-23 17:32:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-23 17:52:59",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-23 17:32:23",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "SearchTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1328616717778468866",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-24 17:15:16"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-24 17:15:17",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328618415955709952",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-25 10:47:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-25 10:48:09",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-25 10:49:34",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-25 10:50:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-25 10:53:20",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328616919872651264",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-25 23:09:48"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-25 23:53:14",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-25 23:53:19",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-25 23:09:55",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-25 23:10:18",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328616919872651264",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-26 01:22:44"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-26 02:28:40",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 01:30:59",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-26 01:23:41",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-26 01:30:43",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-26 01:37:58",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-26 01:23:45",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 01:38:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 01:32:33",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328616919872651264",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-26 03:30:07"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-26 03:31:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 03:31:09",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-26 03:30:16",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-26 03:31:02",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-26 03:30:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 03:30:35",
            "engagementType" : "VideoContentPlayback25"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328617105386733568",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating, Make Friends and Meet New People ANDROID 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-26 07:55:28"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-26 08:03:23",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-26 08:03:25",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1331835423987888128",
              "tweetText" : "Mask Christmas (With 롯백)\n한 해 동안 고생한 모두를 위해\n롯데백화점과 한해가 준비한 노래 선물🎁\n멜론 외 주요음원사이트에서 들어보세요💗\n댓글 이벤트 참여하기👇🏼\nhttps://t.co/5QDcBYyBPs https://t.co/MbH737XjEB",
              "urls" : [ "https://t.co/5QDcBYyBPs" ],
              "mediaUrls" : [ "https://t.co/MbH737XjEB" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76470",
              "name" : "#lottedeptstore20201127",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "롯데백화점",
              "screenName" : "@lotte_deptstore"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-26 17:51:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-26 22:14:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 17:57:07",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-26 17:53:52",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328617047157141505",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-27 06:49:08"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-27 06:49:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-27 06:49:40",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328618482032726016",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating, Make Friends and Meet New People ANDROID 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-27 08:58:30"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-27 09:04:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-27 09:04:24",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328617047157141505",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-27 04:22:36"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-27 04:30:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-27 04:38:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-27 04:49:18",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "SearchTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1328618371915472897",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-27 07:32:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-27 07:32:18",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1329784058172289025",
              "tweetText" : "완전히 달라진 메이플스토리M이 온다!\n귀여움이 쏟아지는 특별한 영상과 함께\n더 비기닝 사전등록 지금 바로 GO!❤\n\n#메이플스토리M_더비기닝 #사전등록",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76488",
              "name" : "#메이플스토리M_더비기닝",
              "description" : "12월, 완전히 달라진 메이플M이 온다! 지금 사전등록 중!"
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리M",
              "screenName" : "@MapleStoryM_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-28 03:35:55"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-28 03:53:59",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-28 03:54:24",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-28 03:54:23",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-28 04:00:46",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-28 03:54:10",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-28 03:54:09",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-28 04:09:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-28 03:54:01",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-28 03:54:02",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-28 03:57:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-28 03:53:57",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-28 03:53:59",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-28 03:53:57",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-28 03:53:55",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-28 03:54:17",
            "engagementType" : "VideoContentPlayback75"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328617047157141505",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-28 04:56:57"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-29 01:45:38",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328617047157141505",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating & Make Friends IOS 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-28 04:56:57"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-28 05:05:24",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-28 05:05:22",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Desktop"
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1331530917106487297",
              "tweetText" : "안녕하세요! 이번엔 막내마케터가 경품을 가지고 왔습니다ㅎㅎ트위터리안이라면 누구나 하나쯤 갖고 있다는 틴더썰.txt...✨#틴더스토리 응모하고 선물 받아가세요!🎁\n\n🔥응모자 전원 TVING 첫달이용권 증정\n🔥홈프로젝터(1명) 올리브영 50만원권(5명)까지\n\n👉지금 참여하기 : https://t.co/isOKoRSdc4",
              "urls" : [ "https://t.co/isOKoRSdc4" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "Desktop"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-28 07:24:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-28 07:24:13",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321715170704420864",
              "tweetText" : "내 인생 최대의 위기를..\n\n하필이면 \n최악의 변태 쿠로에에게 들키고마는데?!\n\n[쿠로에와 에덴의 정원] ⓒChifuyu\n무료회차 보러가기 ▶https://t.co/ovursdA6Ap\n\n#BL #볼레로 #원나잇 #능욕공 #순진수 #웹툰판 https://t.co/kGvJzYe33q",
              "urls" : [ "https://t.co/ovursdA6Ap" ],
              "mediaUrls" : [ "https://t.co/kGvJzYe33q", "https://t.co/kGvJzYe33q", "https://t.co/kGvJzYe33q", "https://t.co/kGvJzYe33q" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "봄툰_작품추천봇",
              "screenName" : "@BOM_TOON"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "사랑"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "절륜공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "레진코믹스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "어른로맨스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "봄툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미인공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "피너툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게이물"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애절물"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "능글공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "데이트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "웹툰추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "자위"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "집착공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미인수"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "추천웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다정공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고수위"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "욕망"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "능력수"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미스터블루"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "어른"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "버프툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "수"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "바텀"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다음웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "후회공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "네이버웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "탑툰"
            }, {
              "targetingType" : "Website Activity"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-05 20:47:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-05 20:48:04",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:48:01",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:48:10",
            "engagementType" : "Detail"
          }, {
            "engagementTime" : "2020-11-05 20:48:03",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:53",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:58",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:56",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:48:00",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:38",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:33",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:36",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:46",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:55",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-05 20:47:41",
            "engagementType" : "EmbeddedMedia"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321403657733074946",
              "tweetText" : "새롭게 찾아온 iPad Air. 전면 화면 디자인에 번개처럼 빠른 속도의 A14 Bionic 칩 탑재. Magic Keyboard, Apple Pencil과의 완벽한 조화. 이 모든 걸 다채로운 매력의 다섯 가지 컬러로 만나보세요. *액세서리는 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327401"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327375"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327414"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24327279"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-06 02:04:33"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-06 04:07:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-06 02:04:43",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-06 02:04:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-06 02:04:43",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-06 02:04:44",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-06 02:04:38",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328618415955709952",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating, Make Friends and Meet New People ANDROID 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-29 01:42:24"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-29 01:45:40",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-29 01:45:44",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1331835423987888128",
              "tweetText" : "Mask Christmas (With 롯백)\n한 해 동안 고생한 모두를 위해\n롯데백화점과 한해가 준비한 노래 선물🎁\n멜론 외 주요음원사이트에서 들어보세요💗\n댓글 이벤트 참여하기👇🏼\nhttps://t.co/5QDcBYyBPs https://t.co/MbH737XjEB",
              "urls" : [ "https://t.co/5QDcBYyBPs" ],
              "mediaUrls" : [ "https://t.co/MbH737XjEB" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76487",
              "name" : "#lottedeptstore20201129",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "롯데백화점",
              "screenName" : "@lotte_deptstore"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-29 01:42:24"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-29 01:48:32",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-29 01:42:28",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-29 01:45:43",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-29 01:44:17",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-29 01:47:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-29 01:43:43",
            "engagementType" : "VideoContentShortFormComplete"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328618415955709952",
              "tweetText" : "틴더 막내마케터입니다... 오피스에서 틧타하다가 틴더 공계 운영을 맡게 되었는데용… 많관부입니다!🥺🔥\n◯ \n   ◯ ╭━━━━━━━━━╮     \n       ┃  다들 Tinder 틴더      ┃\n       ┃   써줬음 좋겠어        ┃\n       ┃   친구든 애인이든… ┃\n       ╰━━━━━━━━━╯",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Tinder Korea",
              "screenName" : "@TinderKorea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Login Tinder - Dating, Make Friends and Meet New People ANDROID 7 Day"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Women"
            } ],
            "impressionTime" : "2020-11-29 05:58:16"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-29 19:02:40",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-29 19:02:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-29 19:02:37",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443492885336064",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "애플"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "맥북"
            }, {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-30 06:02:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-30 06:19:50",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-30 18:35:11",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 06:19:47",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-30 06:19:45",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-30 06:19:48",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-30 06:19:47",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-30 06:20:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 06:19:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 06:19:51",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-30 06:19:45",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-30 06:19:50",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-30 06:19:50",
            "engagementType" : "VideoContentShortFormComplete"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327220421528346626",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#blizzard"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-30 18:31:55"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-30 18:36:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 18:32:01",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333425563160100865",
              "tweetText" : "[#빅톤]\nVICTON 1ST FULL ALBUM\n[VOICE : The future is now]\nTrailer Video [VOICE : Ideal]\n\n🦋 COMING SOON\n\n 🪞 Into The Mirror 마침내 우린\n모든 걸 뛰어넘어 줄 테니\n\n#VICTON #VOICE_The_future_is_now\n#헛되이지_않게_보여줄게_Like_a_truth✨\n#What_I_Said https://t.co/rcHZYFlv56",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/rcHZYFlv56" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76558",
              "name" : "#VICTON110920201201",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "VICTON(빅톤)",
              "screenName" : "@VICTON1109"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-30 18:31:55"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-30 18:37:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 18:31:58",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-30 18:37:35",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 18:44:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 18:36:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-30 23:24:51",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327220421528346626",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#blizzard"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-12-01 23:02:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-01 23:12:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:43:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:31:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:27:54",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:07:28",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-01 23:53:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:05:03",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327220421528346626",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#blizzard"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-12-01 23:02:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-02 00:02:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:14:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:06:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:21:12",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333651069667196928",
              "tweetText" : "왓챠에서 해리포터 만난 기분 요약\n⟨해리포터⟩ 시리즈 지금, 왓챠!\n#헐왓챠에_해리포터 #해리포터 #왓챠",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76550",
              "name" : "#헐왓챠에_해리포터",
              "description" : "전 시리즈는 왓챠에서 감상하세요!"
            },
            "advertiserInfo" : {
              "advertiserName" : "watcha_kr",
              "screenName" : "@watcha_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-01 17:32:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-02 01:24:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:21:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:06:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:14:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 00:02:31",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333651069667196928",
              "tweetText" : "왓챠에서 해리포터 만난 기분 요약\n⟨해리포터⟩ 시리즈 지금, 왓챠!\n#헐왓챠에_해리포터 #해리포터 #왓챠",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76550",
              "name" : "#헐왓챠에_해리포터",
              "description" : "전 시리즈는 왓챠에서 감상하세요!"
            },
            "advertiserInfo" : {
              "advertiserName" : "watcha_kr",
              "screenName" : "@watcha_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-01 17:32:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-01 17:32:13",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-01 23:03:11",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 17:32:35",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:27:54",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:31:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:43:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:53:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 23:12:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-01 17:32:54",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1331876430783791105",
              "tweetText" : "마술양품점에서 기다리고 있을 거야.\n우리가 보고 싶다면, 이곳으로 와\n#마술양품점 #정식OPEN #멋진친구들 #NPC",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마술양품점",
              "screenName" : "@MagicShop_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Girls' Generation"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "뮤직뱅크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악중심"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "차은우"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "노래추천"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "ITZY"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엠넷"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "공연"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-02 14:58:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-02 16:11:54",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-02 16:16:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 16:11:53",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327220421528346626",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#blizzard"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-12-02 09:30:13"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-02 09:38:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 09:38:34",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-02 09:30:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-02 09:39:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 09:41:45",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 09:30:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 09:38:42",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-02 09:38:41",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-02 09:39:06",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1326567547332927489",
              "tweetText" : "지금 콜 오브 듀티 #블랙옵스콜드워를 만나십시오. \n\n차세대 블랙 옵스 멀티플레이어를 만나보십시오. 더욱 풍부한 좀비 모드와 긴장을 풀 수 없는 캠페인이 기다리고 있습니다. \n콜 오브 듀티 #블랙옵스콜드워 수십 년간 계획된 세계적인 음모를 파헤치십시오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Call of Duty",
              "screenName" : "@CallofDuty"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Call of Duty"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-12-02 15:55:16"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-02 16:01:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 16:16:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 15:55:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-02 15:56:40",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1331876597083738113",
              "tweetText" : "2021년 최고의 패션스타!\n마술양품점에 다 모였다!\n너만의 패션을 여기서 뽐내봐\n#마술양품점 #정식OPEN #아바타꾸미기",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마술양품점",
              "screenName" : "@MagicShop_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "모바일게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "세나"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "걸카페건"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "캐주얼게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#갓오브하이스쿨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#걸카페건"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "벽람항로"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#리니지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "넥슨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "리니지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "로오히"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "파이널판타지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "명일방주"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#세나"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓오브하이스쿨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엘소드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니팡"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-02 19:45:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-02 19:46:09",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-02 19:46:02",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-02 19:46:04",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-02 19:46:09",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-02 19:46:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 19:46:05",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-02 22:08:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-02 19:46:03",
            "engagementType" : "VideoContent1secView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1331876597083738113",
              "tweetText" : "2021년 최고의 패션스타!\n마술양품점에 다 모였다!\n너만의 패션을 여기서 뽐내봐\n#마술양품점 #정식OPEN #아바타꾸미기",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마술양품점",
              "screenName" : "@MagicShop_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "모바일게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "세나"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "걸카페건"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "캐주얼게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#갓오브하이스쿨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#걸카페건"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "벽람항로"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#리니지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "넥슨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "리니지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "로오히"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "파이널판타지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "명일방주"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#세나"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓오브하이스쿨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엘소드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니팡"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-02 19:45:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-03 03:42:26",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1334188742580559876",
              "tweetText" : "LIVE NOW ➡️ The Dreamforce to You Keynote with Marc @Benioff and special guests. #DF2U\n\nhttps://t.co/JH0xmQli4T",
              "urls" : [ "https://t.co/JH0xmQli4T" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Salesforce",
              "screenName" : "@salesforce"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Technology"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Huawei"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Internet of things"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "zoom"
            } ],
            "impressionTime" : "2020-12-03 07:27:14"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-03 08:24:46",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-03 09:28:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-03 08:24:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-03 09:39:54",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-03 09:46:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-03 08:24:48",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1334479604598276098",
              "tweetText" : "#새롭게_시작하는_PokemonGO\n\n집에서, 가족과, 산책으로 시작하는 “Pokemon GO”\n새로운 것을 시작하고 싶을 때, 멋진 모습을 보여주고 싶을 때,\n밖에 나갈 핑계가 필요할 때, 시작해 보세요!\n\n#집에서 #가족과 #산책으로 #시작하는\n#포켓몬 #포켓몬스터 #포켓몬고 #포켓몬GO",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76610",
              "name" : "#새롭게_시작하는_PokemonGO",
              "description" : "#집에서 #가족과 #산책으로 시작하는 “Pokemon GO”!"
            },
            "advertiserInfo" : {
              "advertiserName" : "Pokémon GO Korea",
              "screenName" : "@pokemongoappko"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-03 16:22:38"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-03 23:53:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-03 16:22:41",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-03 16:28:23",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-03 22:27:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-03 16:28:25",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1334873845677821956",
              "tweetText" : "메이플M의 새로운 모험을 준비하는\n🎧 핑크빈과 🎶 주황버섯의 환상 케미!\n\n지금, 메이플스토리M 사전등록하고\n12월 17일 달라질 세상을 함께해요!\n\n#메이플스토리M_사전등록 #더비기닝",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76637",
              "name" : "#메이플스토리M_사전등록",
              "description" : "우리는 지금 달라질 세상을 준비 중! 12월 17일 더 비기닝✨"
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리M",
              "screenName" : "@MapleStoryM_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-05 04:32:13"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-05 04:41:04",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-05 04:41:04",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-05 17:28:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-05 04:41:04",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-05 04:41:06",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-05 04:39:31",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-05 04:39:38",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-05 04:41:04",
            "engagementType" : "VideoContentViewV2"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010743324078082",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-06 09:54:01"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-06 09:57:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-06 09:54:41",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-06 09:54:41",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-06 09:54:52",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-11-06 09:58:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-06 09:54:45",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-06 09:54:51",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-11-06 09:54:48",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-11-06 09:54:38",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-06 09:54:39",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-06 09:54:41",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-06 09:54:52",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-11-06 09:54:44",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-11-06 09:54:40",
            "engagementType" : "VideoContentMrcView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1324206258350563328",
              "tweetText" : "선명한 사진, 생동감 넘치는 동영상, DJI Mini 2 하나로 가능합니다. 4K 카메라, 최대 10km 동영상 전송, 인텔리전트 모드를 탑재한 접이식 드론! 영상 제작도 쉽고, 비행은 더 쉬워요! 무게는 249g도 채 안 되는 무게랍니다.\n\n더 알아보기: https://t.co/r9aQCwwuuB",
              "urls" : [ "https://t.co/r9aQCwwuuB" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "DJI",
              "screenName" : "@DJIGlobal"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "laptop"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "Purchase"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-06 09:54:03"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-06 09:54:04",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1321415144627298306",
              "tweetText" : "새롭게 찾아온 iPad Air를 만나보세요. Apple Pencil 하나면 필기는 물론 일러스트 작업, 주석 추가까지 가능하죠. *Apple Pencil은 별매.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-06 04:07:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-06 04:24:00",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-06 04:07:40",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1331788956912865282",
              "tweetText" : "매혹적인 검격, 우아한 승부사!\n#마비노기영웅전 ⭐신규 영웅 테사⭐ 12/10 UPDATE!\n\n괴도를 쫓는 💘아름다운 바운티 헌터의 소문을 들어보셨나요? \n12월 10일, 그녀의 무대가 시작됩니다!\n🎬알아보기&gt; [https://t.co/azeWComOQn] https://t.co/n62zV06yZY",
              "urls" : [ "https://t.co/azeWComOQn" ],
              "mediaUrls" : [ "https://t.co/n62zV06yZY" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기 영웅전",
              "screenName" : "@MabiHeroes"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-06 15:39:19"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-06 15:39:20",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336083097306206209",
              "tweetText" : "[이벤트] \n어느때보다 강력한 파이팅이 필요한 지금 👊\n\n지금 바로 홈페이지 이벤트에 응모하고\n UFC 스냅백과 몬스터 에너지 1박스를 받을 수 있는 기회에 참여하세요.\n\n이벤트 응모 바로가기 👉 https://t.co/Zxfs3Aeb6l https://t.co/XQFN3bv4gz",
              "urls" : [ "https://t.co/Zxfs3Aeb6l" ],
              "mediaUrls" : [ "https://t.co/XQFN3bv4gz" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이벤트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "운동"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-08 17:08:28"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-08 17:08:29",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1311966000762490881",
              "tweetText" : "How’s your team navigating through remote working? Thanks to BCX’s Remote Working Solutions, help your team maintain productivity and efficiency with consistent connectivity and more. Explore more here: https://t.co/MMQzTU7G89 #BCXWorld #BCX https://t.co/as3YnYaFqm",
              "urls" : [ "https://t.co/MMQzTU7G89" ],
              "mediaUrls" : [ "https://t.co/as3YnYaFqm" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "BCX",
              "screenName" : "@BCXworld"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Technology"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "25 and up"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-09 10:03:10"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-09 10:03:12",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-09 10:04:20",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336128412122046465",
              "tweetText" : "Save the date! Join us on December 10th for the commemoration of our 60th anniversary. The event will be broadcast on our social media channels.\n\n#CABEI60Years https://t.co/lUMcQ87lHw",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/lUMcQ87lHw" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "CABEI",
              "screenName" : "@CABEI_Org"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "25 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-09 10:04:52"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-09 10:06:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 10:04:53",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-12-09 10:04:54",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333769531064414210",
              "tweetText" : "선물도 속도전. iPhone 12를 선물해야 할 때.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "운동"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "행복"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "헬스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "건강"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다이어트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "요가"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-09 04:50:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-09 04:58:42",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-09 04:50:35",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-09 04:56:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 05:12:08",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 04:50:31",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-09 04:55:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 04:50:33",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-09 04:50:45",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 04:50:34",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-09 04:51:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 04:50:29",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-09 04:56:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-09 04:50:30",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-09 04:50:34",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-09 04:50:31",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-09 04:50:34",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-09 06:30:19",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336753168538099713",
              "tweetText" : "출시 임박: 카요 페리코 습격\n\n페리코 습격GTA 온라인 역사상 가장 큰 모험, 새롭고 이국적인 습격 위치에서 혼자서 또는 최대 3명과 플레이 가능\n\n12월 15일, PS4와 PS5(하위 호환을 통해)에서 이용 가능",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Rockstar Games",
              "screenName" : "@RockstarGames"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#ps3"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "ps3"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-010-028-gtaops4xb1pc-lapsedplayers-eu_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-011-031-gtaops4xb1pc-activecasino-eu_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-011-032-gtaops4xb1pc-activecasino-latamasia_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-010-029-gtaops4xb1pc-lapsedplayers-latamasia_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "000_GTAO_Payers-Lifetime_18ce54s7sud"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-10 10:46:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-10 10:46:51",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-10 10:46:51",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-12-10 10:46:57",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336972599687987200",
              "tweetText" : "메이플스토리 X 하현우 \n모험의 시작을 알리는 울림 &lt;NEO&gt;🎤\n지금 바로 만나보세요! 🎧\n#메이플스토리 #메이플 #MapleStory",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리",
              "screenName" : "@MapleStory_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "엘소드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "로오히"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "영원한7일의도시"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "메이플 홈페이지 방문자"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-10 11:52:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-10 11:52:13",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-10 11:52:22",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 14:15:44",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 14:15:32",
            "engagementType" : "VideoContent1secView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1336986059247251456",
              "tweetText" : "#NEO업데이트 메이플TV에서 독점공개!\n누구보다 빠르게 메이플스토리 업데이트에 대해 알고싶다면?\n📢 메이플TV가 모두 알려드려요!\n12월 17일, 메이플스토리 NEO 업데이트까지 채널 고정!\n#메이플스토리 #메이플 #메이플TV #mapleTV #메이플티비",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76734",
              "name" : "#NEO업데이트",
              "description" : "12월 17일 메이플스토리 NEO, 지금 채널 고정!"
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리",
              "screenName" : "@MapleStory_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-10 17:31:44"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-10 17:35:59",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 17:32:07",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 23:12:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 17:32:17",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-10 23:06:58",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 22:18:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-10 17:32:16",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-10 17:35:47",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-10 17:32:15",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-10 17:32:17",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-10 17:32:02",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1335690497130717189",
              "tweetText" : "Afterworld: The Age of Tomorrow",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-11 04:28:50"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 04:28:51",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-11 04:29:03",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336083097306206209",
              "tweetText" : "[이벤트] \n어느때보다 강력한 파이팅이 필요한 지금 👊\n\n지금 바로 홈페이지 이벤트에 응모하고\n UFC 스냅백과 몬스터 에너지 1박스를 받을 수 있는 기회에 참여하세요.\n\n이벤트 응모 바로가기 👉 https://t.co/Zxfs3Aeb6l https://t.co/XQFN3bv4gz",
              "urls" : [ "https://t.co/Zxfs3Aeb6l" ],
              "mediaUrls" : [ "https://t.co/XQFN3bv4gz" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "운동"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이벤트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-11 04:28:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 04:29:28",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336905098174242818",
              "tweetText" : "날카롭게, 화려하게! 치명적인 추격자✨\n#마비노기영웅전 신규 영웅 💎테사 업데이트💎\n\n마력의 힘을 레이피어에 실어\n우아하게 적을 제압하는 승부사 테사.\n운명적인 만남, 이 무대에 당신을 초대합니다.\n\n🎬알아보기&gt; [https://t.co/GGKsmDT3bh] https://t.co/v5bxzXWRSo",
              "urls" : [ "https://t.co/GGKsmDT3bh" ],
              "mediaUrls" : [ "https://t.co/v5bxzXWRSo" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기 영웅전",
              "screenName" : "@MabiHeroes"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-11 04:28:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 04:29:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-11 04:29:01",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-12-11 04:29:02",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1335690497130717189",
              "tweetText" : "Afterworld: The Age of Tomorrow",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-11 04:20:02"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 04:26:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-11 04:24:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-11 04:23:16",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-11 05:15:04",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-11 05:15:51",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336945655512588288",
              "tweetText" : "🔸큐라프록스 팝업스토어 일정 안내🔸\n\n골든디스크어워즈 리미티드 에디션의 실물 영접 기회👀\n식품관에서 큐라프록스 팝업스토어를 찾아주세요✔️\n#큐라덴 #큐라프록스 #팝업스토어 https://t.co/mS35titDln",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/mS35titDln", "https://t.co/mS35titDln", "https://t.co/mS35titDln" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "쇼핑"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "패션"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "굿즈"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-11 04:28:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 04:29:13",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1336753168538099713",
              "tweetText" : "출시 임박: 카요 페리코 습격\n\n페리코 습격GTA 온라인 역사상 가장 큰 모험, 새롭고 이국적인 습격 위치에서 혼자서 또는 최대 3명과 플레이 가능\n\n12월 15일, PS4와 PS5(하위 호환을 통해)에서 이용 가능",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76654",
              "name" : "#RockstarGames20201212",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Rockstar Games",
              "screenName" : "@RockstarGames"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-11 19:10:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-12 03:24:45",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-12 01:05:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-12 02:12:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-12 00:51:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-12 00:51:25",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1336753168538099713",
              "tweetText" : "출시 임박: 카요 페리코 습격\n\n페리코 습격GTA 온라인 역사상 가장 큰 모험, 새롭고 이국적인 습격 위치에서 혼자서 또는 최대 3명과 플레이 가능\n\n12월 15일, PS4와 PS5(하위 호환을 통해)에서 이용 가능",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76654",
              "name" : "#RockstarGames20201212",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Rockstar Games",
              "screenName" : "@RockstarGames"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-11 19:10:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 19:15:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-11 19:10:59",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-11 19:12:24",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1335690497130717189",
              "tweetText" : "Afterworld: The Age of Tomorrow",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-11 19:10:15"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-11 19:12:24",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-11 19:10:16",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336933219296399360",
              "tweetText" : "[#알쓸신농] 남극에 채소가 자란다!? 😲\n식물공장이라면 가능해요! 😉\n남극 세종과학기지 대원들에게\n푸릇푸릇 싱싱한 채소를 공급해주는\n남극기지 식물공장❗ 이제 남극에서도\n수박을 맛볼 날이 머지않았어요.\n\n#식물공장 #남극 #세종기지\n#알아두면쓸모있는신기한농업기술\nhttps://t.co/wiIe4FTRK6",
              "urls" : [ "https://t.co/wiIe4FTRK6" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "농촌진흥청",
              "screenName" : "@love_rda"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-13 04:02:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-13 04:02:47",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336905171880747009",
              "tweetText" : "날카롭게, 화려하게! 치명적인 추격자✨\n#마비노기영웅전 신규 영웅 💎테사 업데이트💎\n\n마력의 힘을 레이피어에 실어\n우아하게 적을 제압하는 승부사 테사.\n운명적인 만남, 이 무대에 당신을 초대합니다.\n\n🎬알아보기&gt; [https://t.co/dTDRbtblfq] https://t.co/S3VEW88WoO",
              "urls" : [ "https://t.co/dTDRbtblfq" ],
              "mediaUrls" : [ "https://t.co/S3VEW88WoO" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기 영웅전",
              "screenName" : "@MabiHeroes"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-13 04:02:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-13 04:02:45",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-13 04:02:44",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1334404592805638144",
              "tweetText" : "김하루 선생님과 함께하는\n블로니의 성장지원 속성과외✏\n\n어엿한 밀레시안으로 거듭나고 싶다면?\n에린의 빛나는 영웅이 되고 싶다면?\n쉽고 친절한 블로니의 성장지원이 답🙋♀️🙋♂️\n\n자세히 알아보기 ▶ https://t.co/0l6F6DAjbT https://t.co/2GNpxsJAi2",
              "urls" : [ "https://t.co/0l6F6DAjbT" ],
              "mediaUrls" : [ "https://t.co/2GNpxsJAi2" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-13 04:02:41"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-13 04:02:43",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-12-13 04:02:43",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-13 04:03:14",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1334358443411472385",
              "tweetText" : "다시 만나는 추억담\n“블로니의 성장지원” 절찬 진행 중🌼\n\n아름다운 목소리와 함께 돌아온 블로니🎵\n친절한 블로니와 5000레벨까지 단숨에 성장해보세요.\n쉽고 빠른 스킬 랭크업은 덤,\n블로니가 준비한 특별 개조 무기와 의상까지🎁\n\n자세히 알아보기 ▶ https://t.co/qxcEeZk4wZ https://t.co/15aMYAvq6f",
              "urls" : [ "https://t.co/qxcEeZk4wZ" ],
              "mediaUrls" : [ "https://t.co/15aMYAvq6f" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-13 11:50:35"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-13 11:50:39",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327447214382141440",
              "tweetText" : "기다려온 손맛 iPhone 12 mini. 기대되는 눈맛 iPhone Pro Max. 새로운 두 가지 사이즈, 지금 맛보러 가기.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-14 01:35:25"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-14 02:29:04",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-14 02:29:04",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-14 01:35:30",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-14 01:35:29",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-14 02:29:03",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-14 01:35:27",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-14 01:35:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 02:29:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 01:35:27",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333768218301763584",
              "tweetText" : "빠져드는 사운드. 빠져드는 선물. AirPods Pro.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620055"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620178"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384074"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572772"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620100"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528380"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384060"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383002"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572765"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384035"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384041"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383377"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620216"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528439"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572528"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528293"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383363"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383090"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383250"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572632"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383398"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528394"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24382993"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383360"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24578199"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-13 16:27:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-13 16:27:16",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-13 16:27:17",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-13 16:50:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-13 16:27:12",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-13 16:27:17",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-13 16:27:18",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-13 16:27:17",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-13 16:27:13",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-13 16:27:14",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-13 16:27:14",
            "engagementType" : "VideoContentMrcView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333769505894322178",
              "tweetText" : "선물도 속도전. iPhone 12를 선물해야 할 때.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620055"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620178"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384074"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572772"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620100"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528380"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384060"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383002"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572765"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384035"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384041"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383377"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620216"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528439"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572528"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528293"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383363"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383090"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383250"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572632"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383398"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528394"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24382993"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383360"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24578199"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-14 04:21:45"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-14 04:21:55",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-14 04:21:58",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-14 04:29:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 04:21:57",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-14 04:21:53",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-14 04:32:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 04:22:19",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 04:21:57",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-14 04:45:02",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-14 04:21:52",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-14 04:21:57",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-14 04:21:54",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-14 04:35:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 04:21:58",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-14 04:21:57",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-14 04:21:54",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-14 04:46:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 04:21:56",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-14 04:25:38",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1324260164325826562",
              "tweetText" : "일에 몰입하기 위해 정말로 필요한 것\n\nTalk 8. 토스의 환경: 복리후생, 일, 성장의 상관관계\n\n풀버전 영상 보러가기\n=&gt; https://t.co/dTN0Pi8K9n\n\n일에 대하여, theWORK\nOriginal Content by Toss\n\n아홉 번째 이야기는 \n11월 10일(화)에 공개됩니다.",
              "urls" : [ "https://t.co/dTN0Pi8K9n" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "토스",
              "screenName" : "@Toss_service"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-07 03:31:18"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-07 03:31:19",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-11-07 03:34:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-07 03:31:19",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1324722137878462465",
              "tweetText" : "#GTAOnline 기간 한정 보너스와 할인:\n\n맥스웰 베이그런트 오프로드 버기와 HVY 배라지 30% 할인 등\n\n그리고 타겟 어썰트 레이스에서 보상 세 배\n\n11월 11일 혜택 종료",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Rockstar Games",
              "screenName" : "@RockstarGames"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "cosplay"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#cosplay"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "ps3"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#ps3"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-011-031-gtaops4xb1pc-activecasino-eu_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-010-028-gtaops4xb1pc-lapsedplayers-eu_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "000_GTAO_Payers-Lifetime_18ce54s7sud"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-010-029-gtaops4xb1pc-lapsedplayers-latamasia_18ce54ypdu8"
            }, {
              "targetingType" : "List",
              "targetingValue" : "gtao-011-032-gtaops4xb1pc-activecasino-latamasia_18ce54ypdu8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-07 03:31:18"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-07 03:31:30",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010743324078082",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Massstar"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-06 17:29:26"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-06 17:29:30",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-06 17:32:04",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443477991329794",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-14 23:00:07"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-14 23:00:14",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-14 23:00:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 23:00:14",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-14 23:00:14",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-14 23:00:09",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-14 23:00:09",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-14 23:12:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 23:00:14",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-14 23:00:11",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-14 23:00:11",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-14 23:00:12",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-14 23:56:54",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-14 23:54:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 23:57:43",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 23:07:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-14 23:56:49",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443477991329794",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-14 23:00:07"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 00:15:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 00:11:30",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 01:24:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 00:17:20",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1337386025241501696",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Fashion"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-15 09:23:31"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 09:25:46",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-15 09:53:24",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-15 09:53:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 09:31:23",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1329235971221585920",
              "tweetText" : "#iPhone12studio 에서 나만의 iPhone 12와 iPhone 12 Pro를 디자인해보세요.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-15 07:25:39"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 08:38:22",
            "engagementType" : "CardUrlClick"
          }, {
            "engagementTime" : "2020-12-15 08:38:24",
            "engagementType" : "CloseWebview"
          }, {
            "engagementTime" : "2020-12-15 08:38:24",
            "engagementType" : "DwellShort"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443445917442048",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765382"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765385"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 1"
            }, {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-15 06:14:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 06:30:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:30:37",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-15 06:30:07",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-15 06:32:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:50:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:30:34",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-15 06:14:15",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-15 06:30:35",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-15 06:30:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:30:37",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-15 07:26:02",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:14:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:40:35",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 06:30:37",
            "engagementType" : "VideoContentShortFormComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1337356880797044736",
              "tweetText" : "🏆 Google Play 올해의 베스트 앱 🏆\n쿠팡의 음식배달 앱 #쿠팡이츠 🍕🍔🍣\n\n쿠팡이츠는 한번에 한집만 배달하니까 💙\n빠른 배달 🚀 맛과 따뜻함이 그대로! \n🔐 첫주문 할인쿠폰 코드: ONLY1111 (소근소근)\n#한번에한집배달 #3관왕 \n#올해의_베스트앱\n#올해를_빛낸_인기앱\n#올해를_빛낸_일상생활앱",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Coupang Eats",
              "screenName" : "@CoupangEats"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "만화 작가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#오타쿠"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니메이션과 만화의 용어"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#세이넨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "쇼조"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Show"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니메이션보기"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "최고 망가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#스트림애니메이션"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화의 용어"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#위브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#쇼조"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Shows"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#만화와애니메이션"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#코스프레"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#코도모"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Animation"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "코스프레"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Best Mangas"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#애니메이션보기"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Series"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#수조"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오타쿠"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "수조"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Top Animes"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#애니메이션시리즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "위브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#망가카"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#만화"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 11.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Coupang Eats IOS All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Purchase Coupang Eats IOS All"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-15 12:51:54"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 17:41:05",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-15 17:41:05",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-15 17:41:02",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-15 15:29:06",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 17:41:19",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 15:26:02",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-15 17:41:05",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-15 17:41:04",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-15 15:26:02",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1337385988134490112",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Fashion"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-15 10:04:00"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 10:04:07",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-15 10:04:04",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-15 10:04:07",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-15 10:11:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 10:04:06",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-15 10:04:06",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-15 10:04:05",
            "engagementType" : "VideoContent1secView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1336134601358462977",
              "tweetText" : "자기야 왜 또 씻어..?\n\n혹시 여자친구의 샤워소리가 두렵다면?\n\n지금부터 하루 한 포로 자신감 충전!\n\n#아르맨#남자활력#아르기닌#고함량#자신감",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "강한 남자의 비밀",
              "screenName" : "@Arman_pr1"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Technology"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Soccer"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Government"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "데이트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "남친"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "여친"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "일상"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "커플"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "크리스마스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "남자친구"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Dating"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Weddings"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Marriage"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "25 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-12-15 04:16:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 04:21:06",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-15 04:24:27",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1337386025241501696",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Fashion"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-15 04:32:32"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 04:32:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 04:52:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 04:32:36",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327447214382141440",
              "tweetText" : "기다려온 손맛 iPhone 12 mini. 기대되는 눈맛 iPhone Pro Max. 새로운 두 가지 사이즈, 지금 맛보러 가기.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-15 17:40:57"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-15 17:43:18",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-15 17:41:19",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-15 17:41:13",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-15 17:48:40",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1337385988134490112",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Fashion"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-16 09:46:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 09:46:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 10:04:00",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1337386069579403266",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-16 07:23:06"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 07:25:53",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-16 07:25:50",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-16 07:25:50",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-16 07:25:47",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-16 07:25:48",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-16 07:25:53",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-16 07:31:54",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 07:28:06",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 07:25:52",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-16 07:25:44",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 07:25:47",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-16 07:25:45",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-16 07:25:46",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-16 07:25:45",
            "engagementType" : "VideoContent1secView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333771180759601152",
              "tweetText" : "최신 iPhone 12, Apple Watch 외에도 한가득.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620055"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620178"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384074"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572772"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620100"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528380"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384060"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383002"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572765"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384035"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24384041"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383377"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24620216"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572146"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528439"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572528"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528293"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383363"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383090"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383250"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24572632"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383398"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528394"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24382993"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24383360"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24578199"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-16 10:02:16"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 10:02:31",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-16 10:19:11",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:23:02",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:04:00",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:02:32",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-16 10:02:32",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-16 10:12:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:02:32",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-16 10:18:46",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-16 10:04:00",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:02:25",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-16 10:34:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:02:33",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 10:02:33",
            "engagementType" : "CarouselSwipeNext"
          }, {
            "engagementTime" : "2020-12-16 10:02:36",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-16 10:02:27",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-16 10:33:32",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 10:02:25",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 10:02:34",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-16 10:02:30",
            "engagementType" : "VideoContentPlayback75"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333963278796505089",
              "tweetText" : "Apple Watch Series 6. 건강의 미래도 선물이 됩니다.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-16 12:46:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 12:55:22",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-16 12:55:23",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-16 12:55:21",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-16 12:55:24",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-16 12:55:24",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-16 13:02:44",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 12:55:24",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-16 12:55:24",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-16 12:55:20",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-16 12:55:22",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-16 12:55:18",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 12:55:19",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-16 12:55:24",
            "engagementType" : "VideoContent6secView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338641143009984516",
              "tweetText" : "무지갯빛🌈으로 펼쳐지는\nNCT U의 에너제틱 바이브🔥\n\n#NCT_U #Work_It https://t.co/mvEboks5UB",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/mvEboks5UB" ]
            },
            "publisherInfo" : {
              "publisherName" : "뮤직뱅크 (Music Bank)🏦",
              "screenName" : "@KBSMusicBank"
            },
            "advertiserInfo" : {
              "advertiserName" : "Heineken",
              "screenName" : "@Heineken"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Netflix"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Steak"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Beer"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "TV/Movies Related"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Cooking"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Amazon"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-16 17:26:29"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 17:26:31",
            "engagementType" : "VideoAdPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 17:33:37",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338813164461428736",
              "tweetText" : "카타르항공으로 휴가를 시작하면서 혁신적인 대책, 차원이 다른 럭셔리, 세계적으로 이름난 서비스를 경험하십시오.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Qatar Airways",
              "screenName" : "@qatarairways"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Travel"
            }, {
              "targetingType" : "Events",
              "targetingValue" : "Christmas"
            }, {
              "targetingType" : "Events",
              "targetingValue" : "2020 K리그 시즌"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#travel"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#travelling"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "adventure"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "traveling"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "travelling"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "travel"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "travelers"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "traveler"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-16 17:10:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 17:10:42",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1337386069579403266",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Fashion"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-16 17:10:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 17:11:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:10:52",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1337386025241501696",
              "tweetText" : "Balenciaga Spring 21",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Balenciaga",
              "screenName" : "@BALENCIAGA"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Fashion"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "Seoul"
            } ],
            "impressionTime" : "2020-12-16 17:26:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 23:22:50",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 23:12:40",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 23:16:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:44:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 22:13:50",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-16 17:33:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 23:59:54",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 23:09:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:37:59",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-16 23:53:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:26:14",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 17:31:09",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-16 22:14:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:26:15",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-16 17:31:11",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-16 22:49:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 23:25:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:26:15",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-16 17:26:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 22:13:49",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-16 17:37:58",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-16 17:37:59",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-16 22:14:00",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 22:16:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:31:07",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-16 17:31:12",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-16 22:49:45",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 17:31:07",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-16 17:31:08",
            "engagementType" : "VideoContentPlayback50"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1337223093710884864",
              "tweetText" : "12월 20일까지 몬스터 에너지 홈페이지에서 이벤트에 참여하고 몬스터 에너지 x UFC 스냅백과 몬스터 에너지 1박스 당첨 기회에 지금 바로 도전 👊 이벤트 바로가기 &gt;&gt;https://t.co/Zxfs3Aeb6l https://t.co/yjr5vCiPrl",
              "urls" : [ "https://t.co/Zxfs3Aeb6l" ],
              "mediaUrls" : [ "https://t.co/yjr5vCiPrl" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "이벤트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "운동"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "편의점"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "연말"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "볼캡"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-16 17:26:36"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 17:26:38",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1338276002783350784",
              "tweetText" : "황의조, 골을 향한 갈증 [🇫🇷리그1 HL 14R/ 릴vs보르도] https://t.co/XYar4MweRs",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/XYar4MweRs" ]
            },
            "publisherInfo" : {
              "publisherName" : "SBSSPORTS",
              "screenName" : "@SBSSPORTSNOW"
            },
            "advertiserInfo" : {
              "advertiserName" : "Heineken",
              "screenName" : "@Heineken"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Steak"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Netflix"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Beer"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Cooking"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "TV/Movies Related"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Amazon"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-16 17:09:27"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 17:10:17",
            "engagementType" : "VideoAdPlaybackStart"
          }, {
            "engagementTime" : "2020-12-16 22:13:59",
            "engagementType" : "VideoAdView"
          }, {
            "engagementTime" : "2020-12-16 17:10:17",
            "engagementType" : "VideoAdPlayback25"
          }, {
            "engagementTime" : "2020-12-16 22:13:59",
            "engagementType" : "VideoAdPlayback75"
          }, {
            "engagementTime" : "2020-12-16 22:13:59",
            "engagementType" : "VideoAdViewThreshold"
          }, {
            "engagementTime" : "2020-12-16 22:14:08",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 22:13:58",
            "engagementType" : "VideoAdMrcView"
          }, {
            "engagementTime" : "2020-12-16 22:13:58",
            "engagementType" : "VideoAdPlayback50"
          }, {
            "engagementTime" : "2020-12-16 17:10:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-16 22:13:57",
            "engagementType" : "VideoAd1secView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338793424850284545",
              "tweetText" : "Stay up to date in tech!\n\nALL Packt eBooks and Videos are now $5! 🙌\n\nIt’s time to unlock new opportunities and put software to work in new ways.\n\nClick here: 👉 https://t.co/oC0Deo4DiO\n\n#packt #techunlocked #$5 https://t.co/4DFZjxhAfC",
              "urls" : [ "https://t.co/oC0Deo4DiO" ],
              "mediaUrls" : [ "https://t.co/4DFZjxhAfC" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Packt",
              "screenName" : "@PacktPub"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            } ],
            "impressionTime" : "2020-12-16 17:33:24"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-16 17:33:25",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443425558294528",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 10:53:23"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 10:59:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 16:37:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 10:53:36",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-17 10:53:34",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-17 10:53:37",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-17 10:53:33",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-17 10:53:33",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-17 10:53:35",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-17 10:53:36",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-17 10:53:36",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-17 11:01:01",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 10:57:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 11:05:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 11:20:27",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 10:53:35",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-17 10:53:31",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-17 10:55:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 10:53:33",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-17 11:20:07",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-17 10:53:31",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 10:59:08",
            "engagementType" : "VideoContentShortFormComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339089749806497794",
              "tweetText" : "💸클래스101에서 당신의 재능을 삽니다💸\n\n🔥TOP 100명 평균 정산액이 1억!\n🔥첫 달 평균 정산액이 600만원 +!\n\n내가 받을 정산액을 확인해보세요!\n\n👉 영상 제작을 할 줄 몰라도 괜찮아요\n클래스를 성공적으로 오픈 할 수 있도록\n클래스101에서 도와드릴게요!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "클래스101",
              "screenName" : "@class101_kr"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 05:10:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 05:10:17",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-17 05:10:15",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 05:10:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 05:10:18",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-17 05:13:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 05:19:07",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 05:13:12",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-17 07:23:50",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1328945897590431750",
              "tweetText" : "요즘 누가 밖에서 놀아? 🤷‍♀️\n심심할땐 쿠키런하세요 ❤️\n매일 출석만해도 40만원 상당의 선물을 쏩니다!\n\n#쿠키런 #쿠키런오븐브레이크",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런 : 오븐브레이크",
              "screenName" : "@CookieRunKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "배린이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "파이널판타지"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이러브커피"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엘소드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모바일게임"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 8.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 05:10:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 05:19:04",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 05:19:07",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1339420056166555648",
              "tweetText" : "곧 별빛이 하나로 모인다.\n마비노기 스타더스트 2차 사전등록 오픈!\n\n1차 사전등록, 진행하셨다구요?\n2차에도 참여하고 넥슨캐시 한 번 더 받아가세요🎁\n\n지금 참여하기 ▶ https://t.co/Hh5KMKRODl https://t.co/hKHPJ52KSl",
              "urls" : [ "https://t.co/Hh5KMKRODl" ],
              "mediaUrls" : [ "https://t.co/hKHPJ52KSl" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-17 05:10:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 05:10:23",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443425558294528",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 08:29:17"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 09:36:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 08:29:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 09:33:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 09:35:58",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-17 08:29:22",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 08:29:20",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1327443477991329794",
              "tweetText" : "쏙 들어오는 크기, 똑소리 나는 성능. 5G로 만나는 iPhone 12 mini.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 07:21:19"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 07:21:35",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-17 07:21:33",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-17 07:21:34",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-17 07:21:30",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 07:21:36",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-17 07:21:31",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-17 07:23:50",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 08:29:22",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 07:21:36",
            "engagementType" : "VideoContentPlaybackComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339118138932121602",
              "tweetText" : "[PBA베스트샷/블루원엔젤스] 이 배치 어떻게 풀려고?? 궁금증 유발샷 https://t.co/XPufbkTcmI",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/XPufbkTcmI" ]
            },
            "publisherInfo" : {
              "publisherName" : "SBSSPORTS",
              "screenName" : "@SBSSPORTSNOW"
            },
            "advertiserInfo" : {
              "advertiserName" : "Heineken",
              "screenName" : "@Heineken"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Cooking"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "TV/Movies Related"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Amazon"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Netflix"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Steak"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Beer"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 04:19:08"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 04:38:25",
            "engagementType" : "VideoAdPlayback50"
          }, {
            "engagementTime" : "2020-12-17 04:21:02",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-17 04:19:20",
            "engagementType" : "VideoAdShortFormComplete"
          }, {
            "engagementTime" : "2020-12-17 04:38:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 04:19:18",
            "engagementType" : "VideoAdPlayback75"
          }, {
            "engagementTime" : "2020-12-17 04:21:06",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 04:19:20",
            "engagementType" : "VideoAd6secView"
          }, {
            "engagementTime" : "2020-12-17 04:19:22",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 04:19:17",
            "engagementType" : "VideoAdMrcView"
          }, {
            "engagementTime" : "2020-12-17 04:19:15",
            "engagementType" : "VideoAdPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 04:23:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 04:19:21",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 04:23:28",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-17 04:19:15",
            "engagementType" : "VideoAdPlayback25"
          }, {
            "engagementTime" : "2020-12-17 04:21:04",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-17 04:19:17",
            "engagementType" : "VideoAdPlayback50"
          }, {
            "engagementTime" : "2020-12-17 04:19:20",
            "engagementType" : "VideoAdPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-17 04:19:19",
            "engagementType" : "VideoAdPlayback95"
          }, {
            "engagementTime" : "2020-12-17 04:19:21",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-17 04:38:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 04:25:45",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1339427601388068864",
              "tweetText" : "지상으로 끌어내려진 하늘의 파편,\n당신에게 이끌리는 미지의 힘.\n\n이제 그 힘을 받아들일 준비를 시작하세요.\n\n마비노기 스타더스트 업데이트\n\n2차 사전등록 ▶ https://t.co/OuN28rP0Qq\n스타더스트 알아보기 ▶ https://t.co/XrpiaFrKOr https://t.co/3P2xPFKBN0",
              "urls" : [ "https://t.co/OuN28rP0Qq", "https://t.co/XrpiaFrKOr" ],
              "mediaUrls" : [ "https://t.co/3P2xPFKBN0" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-18 03:25:48"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-18 03:25:49",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339443852361433090",
              "tweetText" : "#메이플스토리NEO\n그란디스에서 펼쳐지는 새로운 이야기\n집결하라! 숙적에 대적하기 위해\n그리고 새로운 미래를 위해!\n#메이플스토리 #MapleStory #메이플업데이트 #네오",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76900",
              "name" : "#메이플스토리NEO",
              "description" : "대적자여, 새로운 숙적에 맞서라!"
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리",
              "screenName" : "@MapleStory_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-17 16:20:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-17 16:37:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-17 16:21:00",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1339137175137349632",
              "tweetText" : "큐라프록스 골든디스크 기념이벤트✨\n골든디스크 리미티드 에디션 구매하고 SNS에서 인증해주세요! 큐라프록스가 아티스트에게 응원메세지와 선물을 전달해드립니다. 응모자는 별도 추첨을 통해 아이패드 에어를 선물로 드려요!\n#골든디스크 #큐라프록스 #골디큐라덴 #아티스트이름\n📌기간:12.17~12.31 https://t.co/1Jv65f0deo",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/1Jv65f0deo", "https://t.co/1Jv65f0deo" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#ITZY"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "몬스타엑스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "더보이즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "은우"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "기현"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "뉴이스트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#멜론"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#음악중심"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지코"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#차은우"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "하성운"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#하성운"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Got7"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이유(Iu) 공식 트위터"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#기현"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음중"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#민호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#콘서트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#샤이니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#갓세븐"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "ITZY"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#지코"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악중심"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#몬스타엑스"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#은우"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#더보이즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "차은우"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#뉴이스트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#Got7"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Music festivals and concerts"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "V (BTS)"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BLACKPINK"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-18 09:19:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-18 09:19:23",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338712868561317889",
              "tweetText" : "[이벤트] 이번 주 주말 종료!! 놓칠 수 없는 이번 이벤트의 1등 상품은 몬스터 에너지 UFC 스냅백과 몬스터 에너지 1박스(24캔)! 😎 지금 바로 이벤트 에참여하세요! https://t.co/Zxfs3Aeb6l https://t.co/Iel3IExCxG",
              "urls" : [ "https://t.co/Zxfs3Aeb6l" ],
              "mediaUrls" : [ "https://t.co/Iel3IExCxG" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "연말"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "편의점"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이벤트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "운동"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 49"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-18 09:19:33"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-18 09:19:34",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1338802286378635265",
              "tweetText" : "반가워요 5G. iPhone 12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765382"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765330"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528380"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765358"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765341"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528439"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528293"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24765350"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24528394"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-18 09:18:08"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-18 09:18:16",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-18 09:18:16",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-18 09:18:15",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-18 09:18:11",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-18 09:18:16",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-18 09:18:13",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-18 09:18:17",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-18 09:24:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-18 09:18:14",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-18 09:18:14",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-18 09:18:15",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-18 09:18:15",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-18 09:18:10",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-18 09:19:54",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1338802341013688321",
              "tweetText" : "반가워요 5G. iPhone 12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지혜 큐빅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아트바바"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "테이크 아웃 도면"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "개념 미술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "에미 위 blm"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art brücke"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "소낭구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스케치"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "홍익대학교"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "sungkyunkwan university"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "halsey 팬 art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트 브러쉬"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "on reconstruction"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-19 01:23:22"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-19 01:37:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 01:23:35",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-19 01:23:36",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-19 01:23:38",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-19 01:24:08",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-19 01:23:40",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-19 01:23:39",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-19 01:23:39",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-19 01:32:21",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-19 01:24:10",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-19 01:23:34",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-19 01:32:23",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-19 01:32:23",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-19 02:09:35",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339946017819648001",
              "tweetText" : "마침내 깨어난 궁극의 힘 「V」\n새로운 힘으로 완성될 거대한 변화를\n지금 메이플스토리M에서 확인하세요\n\n지금 다운로드 &gt; https://t.co/8zC02MqzsX\n\n#메이플스토리M_V #5차전직 #아케인리버 https://t.co/URr8Zfh585",
              "urls" : [ "https://t.co/8zC02MqzsX" ],
              "mediaUrls" : [ "https://t.co/URr8Zfh585" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76947",
              "name" : "#메이플스토리M_V",
              "description" : "깨어난 힘, 거대한 변화의 완성"
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리M",
              "screenName" : "@MapleStoryM_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-18 16:08:15"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-19 00:59:03",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339946017819648001",
              "tweetText" : "마침내 깨어난 궁극의 힘 「V」\n새로운 힘으로 완성될 거대한 변화를\n지금 메이플스토리M에서 확인하세요\n\n지금 다운로드 &gt; https://t.co/8zC02MqzsX\n\n#메이플스토리M_V #5차전직 #아케인리버 https://t.co/URr8Zfh585",
              "urls" : [ "https://t.co/8zC02MqzsX" ],
              "mediaUrls" : [ "https://t.co/URr8Zfh585" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76947",
              "name" : "#메이플스토리M_V",
              "description" : "깨어난 힘, 거대한 변화의 완성"
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리M",
              "screenName" : "@MapleStoryM_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-18 16:08:15"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-18 16:09:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-18 16:08:33",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333769550433644546",
              "tweetText" : "선물도 속도전. iPhone 12를 선물해야 할 때.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "retailmenot com"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-19 05:31:46"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-19 11:18:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 05:32:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 05:32:54",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333769550433644546",
              "tweetText" : "선물도 속도전. iPhone 12를 선물해야 할 때.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "retailmenot com"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-19 11:17:29"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-19 11:19:31",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-19 11:18:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 11:18:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 11:25:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 11:21:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 11:19:29",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-19 11:17:44",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-19 11:19:31",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-19 11:19:30",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-19 11:19:32",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-19 11:17:48",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-19 11:19:31",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-19 11:17:44",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1324199624886816770",
              "tweetText" : "세상을 새로운 시각으로, DJI Mini 2와 함께하세요. 강력한 카메라, 인텔리전트 모드 사양을 자랑하는 DJI의 초소형, 초경량 드론! 어디서든 개성 넘치는 근사한 영상을 완벽하게 만들어줍니다.\n\n더 알아보기: https://t.co/r9aQCwwuuB",
              "urls" : [ "https://t.co/r9aQCwwuuB" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "DJI",
              "screenName" : "@DJIGlobal"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "laptop"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "Purchase"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-07 11:38:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-07 11:38:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-07 11:38:06",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-07 11:38:05",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-11-07 11:38:09",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1324205984890286080",
              "tweetText" : "선명한 사진, 생동감 넘치는 동영상, DJI Mini 2 하나로 가능합니다. 4K 카메라, 최대 10km 동영상 전송, 인텔리전트 모드를 탑재한 접이식 드론! 영상 제작도 쉽고, 비행은 더 쉬워요! 무게는 249g도 채 안 되는 무게랍니다.\n\n더 알아보기: https://t.co/r9aQCwwuuB",
              "urls" : [ "https://t.co/r9aQCwwuuB" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "DJI",
              "screenName" : "@DJIGlobal"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "laptop"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "Purchase"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Gender",
              "targetingValue" : "Men"
            } ],
            "impressionTime" : "2020-11-07 06:58:21"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-07 06:58:22",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339734308362178561",
              "tweetText" : "\"의무도 책임도 아니야. 이것이 내 의지\"\n \n엘소드 신규 캐릭터 노아\n1라인 3차 전직 업데이트 완료!\nhttps://t.co/lNTdHFxV2L\n \n오늘 오후 6시부터\n모험가님댁에 넥슨캐시 노아드릴 눈치게임 시작!\n노아를 위한 첫 겨울맞이 이벤트와\n강화데이도 놓치지 마세요!\n \n#엘소드_노아_너는_내가_지켜줄게",
              "urls" : [ "https://t.co/lNTdHFxV2L" ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76993",
              "name" : "#엘소드_노아_너는_내가_지켜줄게",
              "description" : "엘소드 신규 캐릭터 노아, 1라인 3차 전직 ‘리버레이터’ 업데이트! 그림자의 주인으로 거듭난 노아를 지금 바로 만나보세요!"
            },
            "advertiserInfo" : {
              "advertiserName" : "엘소드(ELSWORD)",
              "screenName" : "@ELSWORD_KOG"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-19 18:54:23"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 00:15:57",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339734308362178561",
              "tweetText" : "\"의무도 책임도 아니야. 이것이 내 의지\"\n \n엘소드 신규 캐릭터 노아\n1라인 3차 전직 업데이트 완료!\nhttps://t.co/lNTdHFxV2L\n \n오늘 오후 6시부터\n모험가님댁에 넥슨캐시 노아드릴 눈치게임 시작!\n노아를 위한 첫 겨울맞이 이벤트와\n강화데이도 놓치지 마세요!\n \n#엘소드_노아_너는_내가_지켜줄게",
              "urls" : [ "https://t.co/lNTdHFxV2L" ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76993",
              "name" : "#엘소드_노아_너는_내가_지켜줄게",
              "description" : "엘소드 신규 캐릭터 노아, 1라인 3차 전직 ‘리버레이터’ 업데이트! 그림자의 주인으로 거듭난 노아를 지금 바로 만나보세요!"
            },
            "advertiserInfo" : {
              "advertiserName" : "엘소드(ELSWORD)",
              "screenName" : "@ELSWORD_KOG"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-19 18:54:23"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-19 18:55:06",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-19 19:11:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 18:54:46",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-19 18:55:14",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-19 18:54:52",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-19 18:54:37",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-19 18:57:58",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-19 18:54:56",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-19 18:55:16",
            "engagementType" : "VideoContentPlaybackComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336945655512588288",
              "tweetText" : "🔸큐라프록스 팝업스토어 일정 안내🔸\n\n골든디스크어워즈 리미티드 에디션의 실물 영접 기회👀\n식품관에서 큐라프록스 팝업스토어를 찾아주세요✔️\n#큐라덴 #큐라프록스 #팝업스토어 https://t.co/mS35titDln",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/mS35titDln", "https://t.co/mS35titDln", "https://t.co/mS35titDln" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "패션"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "뷰티"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "굿즈"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "쇼핑"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-19 18:54:26"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-19 18:54:30",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333963328364847104",
              "tweetText" : "Apple Watch Series 6. 건강의 미래도 선물이 됩니다.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "retailmenot com"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-20 08:37:35"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 08:38:03",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-20 08:55:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 08:38:06",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-20 08:38:06",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-20 08:38:05",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-20 08:38:06",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-20 08:38:01",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-20 08:38:02",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339159246504513537",
              "tweetText" : "대망의 앙상블스타즈!!가 새롭게 돌아왔습니다.\n아이돌을 육성하는 즐거움을 만끽해보세요!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "앙상블스타즈!!",
              "screenName" : "@enstars2_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Shows"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Animation"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Movies"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#무료"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "앱"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "무료"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#망가읽기"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 온라인 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Show"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화 작가"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "WiFi only targeting",
              "targetingValue" : "WiFi-only"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-20 07:54:02"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 08:37:36",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-20 08:55:53",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333768262438449158",
              "tweetText" : "빠져드는 사운드. 빠져드는 선물. AirPods Pro.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "retailmenot com"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-20 07:01:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 07:01:50",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-20 07:01:51",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-20 07:54:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 07:01:57",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-20 07:01:54",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-20 07:01:58",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333768262438449158",
              "tweetText" : "빠져드는 사운드. 빠져드는 선물. AirPods Pro.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "retailmenot com"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-20 04:04:38"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 04:04:48",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-20 04:04:47",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-20 04:04:47",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-20 04:04:47",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-20 04:04:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:59:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:07:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:12:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:30:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:04:47",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-20 04:07:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 07:01:58",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:04:42",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-20 04:24:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:22:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 04:04:39",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-20 04:12:29",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-20 04:12:27",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-20 04:04:48",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-20 04:04:49",
            "engagementType" : "VideoContent6secView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339159246504513537",
              "tweetText" : "대망의 앙상블스타즈!!가 새롭게 돌아왔습니다.\n아이돌을 육성하는 즐거움을 만끽해보세요!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "앙상블스타즈!!",
              "screenName" : "@enstars2_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Show"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "앱"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Movies"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#무료"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "만화 작가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#망가읽기"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Shows"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "무료"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "최고의 온라인 게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#Anime"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Anime Animation"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "WiFi only targeting",
              "targetingValue" : "WiFi-only"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-20 09:03:34"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 09:07:46",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-20 09:34:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 09:07:41",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-20 09:08:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 09:07:29",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-20 09:04:52",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-20 09:07:44",
            "engagementType" : "VideoContentPlayback25"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340673311089442817",
              "tweetText" : "#트릭스터M 캐릭터&amp;컴퍼니 사전 생성 진행 중!\n\n지금 바로 나만의 캐릭터를 선점하고\n드릴 넘치는 모험과 도전을 준비하세요!\n\n#트릭스터 #트릭스터캐릭터 #캐릭터사전생성\n#끝없는모험 #신상도트 #미완의이야기\n#모바일게임 #MMORPG #엔씨소프트 #NC\n#PURPLE #퍼플 #퍼플에서발견",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76988",
              "name" : "#NCSOFT20201221",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "엔씨소프트(NCSOFT)",
              "screenName" : "@NCSOFT"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-20 17:01:55"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-20 17:32:35",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 17:02:01",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-20 17:02:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-20 17:02:00",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1339202706708156417",
              "tweetText" : "#앙상블스타즈!! 정식 출시\n접속만 해도\n★4 이상 카드 1장 획득!  \n마음에 드는 아이돌을 만날 때까지 \n반복 스카우트 가능!!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "앙상블스타즈!!",
              "screenName" : "@enstars2_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Jimin"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "RM"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Jungkook"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "K-pop"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Jin"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "V (BTS)"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "J-pop"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Music festivals and concerts"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 9.0 and above"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-21 06:30:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-21 07:35:21",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 06:39:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 06:30:51",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-21 06:30:52",
            "engagementType" : "VideoContent1secView"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333768262438449158",
              "tweetText" : "빠져드는 사운드. 빠져드는 선물. AirPods Pro.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "retailmenot com"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-21 10:44:31"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-21 10:54:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 10:50:39",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 10:44:33",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-21 10:56:10",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 11:02:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 11:05:58",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339046118471081984",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-21 09:23:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-21 09:24:02",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-21 09:41:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:24:13",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:20",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-21 09:24:14",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-21 09:26:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:24:13",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:16",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-21 09:24:08",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:16",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-21 09:24:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:24:09",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-21 09:24:12",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-21 09:24:08",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-21 09:23:56",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-21 09:24:06",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-21 09:24:10",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-21 09:24:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:23:52",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-21 09:24:21",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-21 09:24:14",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-21 09:41:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:23:48",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-21 09:24:00",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:11",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-21 09:23:59",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-21 09:24:07",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-21 09:24:00",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:23",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:23",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-21 09:24:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 10:03:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:23:45",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-21 09:24:13",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-21 09:51:24",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:45:33",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:24:01",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-21 09:24:23",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-21 09:24:07",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-21 09:24:04",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-21 09:24:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 09:23:51",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-21 09:24:18",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-21 09:24:03",
            "engagementType" : "VideoContentMrcView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339046245478793219",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트 브러쉬"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "halsey 팬 art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "테이크 아웃 도면"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아트바바"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "on reconstruction"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지혜 큐빅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "소낭구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "개념 미술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art brücke"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "sungkyunkwan university"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스케치"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "designer"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "홍익대학교"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-22 02:31:26"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 02:31:46",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 03:21:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 02:35:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 02:31:32",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1339432380033986563",
              "tweetText" : "✉ 용사님을 초대합니다! \n다양한 혜택으로 마법같은 성장을 경험할 수 있는 네오 캐슬에!\n#메이플스토리 #MapleStory #메이플업데이트 #네오코인샵",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리",
              "screenName" : "@MapleStory_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Sci-fi and fantasy"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Animation"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "쿠키런"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엘소드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모두의마블"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니팡"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "연애게임"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "메이플 홈페이지 방문자"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-21 22:01:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-21 22:01:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 22:01:50",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1338820536814641153",
              "tweetText" : "새롭게 선보이는 iPhone 12",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76730",
              "name" : "#Apple20201222",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-21 16:59:47"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-21 22:15:47",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-21 17:00:12",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-21 17:00:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 22:01:51",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-21 22:00:41",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-21 22:01:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 17:00:13",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-21 23:14:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 17:00:10",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-21 22:15:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-21 22:01:51",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-21 22:00:41",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-21 17:00:11",
            "engagementType" : "VideoContent1secView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333771521655914496",
              "tweetText" : "최신 iPhone 12, Apple Watch 외에도 한가득.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이폰"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-22 10:26:53"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 10:57:58",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-22 10:57:53",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-22 10:57:52",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-22 10:57:51",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-22 10:27:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 10:57:58",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-22 10:27:00",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-22 10:58:00",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 11:37:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 10:57:50",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-22 10:57:52",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-22 10:57:58",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-22 10:26:59",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-22 10:57:51",
            "engagementType" : "VideoContentPlayback50"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339046245478793219",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "art brücke"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "소낭구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스케치"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "sungkyunkwan university"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트 브러쉬"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "halsey 팬 art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "테이크 아웃 도면"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아트바바"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "on reconstruction"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "홍익대학교"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "designer"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지혜 큐빅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "개념 미술"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-22 06:24:49"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 06:31:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 06:25:39",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-22 06:24:55",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-22 06:28:07",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 06:30:56",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333771288054173696",
              "tweetText" : "최신 iPhone 12, Apple Watch 외에도 한가득.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "행복"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "건강"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "운동"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다이어트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "헬스"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-22 08:33:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 09:12:26",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 09:49:01",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 09:37:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 08:33:30",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-22 09:32:42",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 09:58:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 08:33:30",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-22 08:33:22",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-22 08:33:54",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-22 08:33:50",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-22 08:33:29",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-22 09:10:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 08:33:51",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-22 08:33:27",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-22 08:33:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 08:33:52",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-22 08:33:30",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-22 08:33:52",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-22 08:33:20",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-22 08:33:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 09:32:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 09:26:21",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1339427601388068864",
              "tweetText" : "지상으로 끌어내려진 하늘의 파편,\n당신에게 이끌리는 미지의 힘.\n\n이제 그 힘을 받아들일 준비를 시작하세요.\n\n마비노기 스타더스트 업데이트\n\n2차 사전등록 ▶ https://t.co/OuN28rP0Qq\n스타더스트 알아보기 ▶ https://t.co/XrpiaFrKOr https://t.co/3P2xPFKBN0",
              "urls" : [ "https://t.co/OuN28rP0Qq", "https://t.co/XrpiaFrKOr" ],
              "mediaUrls" : [ "https://t.co/3P2xPFKBN0" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Computer gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-22 11:28:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 11:37:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 11:28:43",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2020-12-22 11:28:44",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1341192266212229120",
              "tweetText" : "#GO_BEYOND\n\n“Pokemon GO” GO BEYOND!\n칼로스지방의 포켓몬이 등장했습니다!\n선물과 포켓스톱을 확인하고\n몬스터볼을 준비하세요!✨\n\n#GOBEYOND #칼로스지방 #몬스터볼 \n#포켓몬 #포켓몬스터 #포켓몬고 #포켓몬GO",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76982",
              "name" : "#GO_BEYOND",
              "description" : "“Pokemon GO”에 #칼로스지방의 #포켓몬이 등장했습니다!  모두들 #몬스터볼을 준비하세요✨"
            },
            "advertiserInfo" : {
              "advertiserName" : "Pokémon GO Korea",
              "screenName" : "@pokemongoappko"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-22 18:17:13"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 23:07:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 18:17:16",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-22 18:27:13",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339046245478793219",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "designer"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "개념 미술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지혜 큐빅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아트바바"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "on reconstruction"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "테이크 아웃 도면"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트 브러쉬"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "halsey 팬 art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art brücke"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "소낭구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스케치"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "홍익대학교"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "sungkyunkwan university"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인트"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-22 18:17:13"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-22 18:22:59",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-22 23:54:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 18:27:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-22 23:07:13",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1339045794087751682",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-23 02:28:16"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-23 04:32:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 02:28:34",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-23 02:28:20",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 02:28:33",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-23 02:28:31",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-23 02:33:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 06:19:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 02:28:30",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-23 02:30:41",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333771088669470720",
              "tweetText" : "최신 iPhone 12, Apple Watch 외에도 한가득.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-23 09:19:35"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-23 09:22:37",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-23 09:19:40",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 09:22:37",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-23 09:22:39",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 09:22:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:22:41",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:19:41",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-23 09:50:07",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:40:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:22:36",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-23 09:22:34",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-23 09:22:39",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-23 09:22:37",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-23 10:04:01",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:39:51",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:50:35",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:21:43",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 10:03:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 09:19:59",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1341283199427596288",
              "tweetText" : "✨큐라프록스 골든디스크 기념 이벤트✨\n\n최애와 커플칫솔 쓰는 방법❣️\n골디 리미티드 에디션 구매하고 SNS에서 인증하면,\n큐라프록스가 아티스트에게 응원메세지와 선물을 직접 전달해드려요! (12.31까지)\n\n📌필수 해시태그\n#골든디스크 #큐라프록스 #골디큐라덴 #아티스트이름 https://t.co/MiLaFHmE3Z",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/MiLaFHmE3Z", "https://t.co/MiLaFHmE3Z" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "V (BTS)"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BLACKPINK"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이유(Iu) 공식 트위터"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "한국 음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#이하이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "ITZY"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "뮤직뱅크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "여자 친구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#ITZY"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#뮤직뱅크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이하이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#카이"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-23 09:39:41"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-23 09:39:42",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340945107701391362",
              "tweetText" : "황의조의 창, 가와시마의 방패 뚫었지만... [리그1] https://t.co/IJj7BKL3jr",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/IJj7BKL3jr" ]
            },
            "publisherInfo" : {
              "publisherName" : "SBSSPORTS",
              "screenName" : "@SBSSPORTSNOW"
            },
            "advertiserInfo" : {
              "advertiserName" : "Heineken",
              "screenName" : "@Heineken"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Beer"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Steak"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Netflix"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Amazon"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "TV/Movies Related"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Cooking"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-23 10:02:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-23 10:02:47",
            "engagementType" : "VideoAdPlayback95"
          }, {
            "engagementTime" : "2020-12-23 10:08:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 10:02:48",
            "engagementType" : "VideoAdShortFormComplete"
          }, {
            "engagementTime" : "2020-12-23 10:04:01",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 10:08:04",
            "engagementType" : "VideoAdPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-23 10:03:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 10:02:48",
            "engagementType" : "VideoAdPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-23 10:08:03",
            "engagementType" : "VideoAd1secView"
          }, {
            "engagementTime" : "2020-12-23 10:03:06",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-23 10:02:49",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 10:02:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 10:02:42",
            "engagementType" : "VideoAdPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 10:08:03",
            "engagementType" : "VideoAdMrcView"
          }, {
            "engagementTime" : "2020-12-23 10:02:42",
            "engagementType" : "VideoAdPlayback25"
          }, {
            "engagementTime" : "2020-12-23 10:02:46",
            "engagementType" : "VideoAdPlayback75"
          }, {
            "engagementTime" : "2020-12-23 10:02:43",
            "engagementType" : "VideoAdPlayback50"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333768285377105920",
              "tweetText" : "빠져드는 사운드. 빠져드는 선물. AirPods Pro.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "아이폰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애플giveback"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-23 11:53:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-23 11:59:39",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-23 12:00:05",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 11:59:41",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-23 11:59:41",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-23 12:02:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 11:59:38",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-23 11:59:41",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-23 11:59:12",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 14:05:25",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2020-12-23 14:10:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 15:37:04",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 11:59:13",
            "engagementType" : "VideoContentPlayback25"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333769585665867776",
              "tweetText" : "선물도 속도전. iPhone 12를 선물해야 할 때.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "애플giveback"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-24 02:26:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-24 02:27:22",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-24 02:27:40",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 02:35:08",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1341192266212229120",
              "tweetText" : "#GO_BEYOND\n\n“Pokemon GO” GO BEYOND!\n칼로스지방의 포켓몬이 등장했습니다!\n선물과 포켓스톱을 확인하고\n몬스터볼을 준비하세요!✨\n\n#GOBEYOND #칼로스지방 #몬스터볼 \n#포켓몬 #포켓몬스터 #포켓몬고 #포켓몬GO",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76983",
              "name" : "#GO_BEYOND",
              "description" : "“Pokemon GO”에 #칼로스지방의 #포켓몬이 등장했습니다!  모두들 #몬스터볼을 준비하세요✨"
            },
            "advertiserInfo" : {
              "advertiserName" : "Pokémon GO Korea",
              "screenName" : "@pokemongoappko"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-23 17:12:59"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-23 17:22:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 17:13:05",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-23 17:17:54",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-23 17:37:36",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 17:17:52",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-23 17:13:03",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-23 17:13:09",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-23 17:13:11",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-23 17:14:48",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-23 17:30:43",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338997297485582353",
              "tweetText" : "[연말 특별★이벤트] \n한정수량으로 제작한 몬스터 에너지 2021 캘린더와 다양한 몬스터 에너지 아이템이 담긴 기프트박스 득템 기회!\n이벤트 바로가기&gt;&gt; https://t.co/OZ0IDyHTn2 https://t.co/17LKId0NHw",
              "urls" : [ "https://t.co/OZ0IDyHTn2" ],
              "mediaUrls" : [ "https://t.co/17LKId0NHw", "https://t.co/17LKId0NHw" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "캘린더"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            } ],
            "impressionTime" : "2020-12-24 09:48:41"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-24 09:48:42",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333771626790350850",
              "tweetText" : "최신 iPhone 12, Apple Watch 외에도 한가득.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "애플giveback"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-24 04:23:57"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-24 04:56:07",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 05:29:06",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 05:13:57",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 04:56:21",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 04:55:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-24 04:55:20",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-24 05:27:55",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 05:06:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 05:11:47",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-24 05:04:37",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1323444790273323009",
              "tweetText" : "두 가지 모습으로 트렌디하게\n\nCompleting signature look with my own trend\n2020 FILA Winter Collection\n\n💜 제품 확인하기 : https://t.co/r6DMzTfdvF\n\n#휠라 #FILA #방탄소년단 #BTS #RM #진 #슈가 #제이홉 #지민 #뷔 #정국 \n#Jin #SUGA #jhope #Jimin #V #JungKook #FILAONTHESTREET @BTS_twt https://t.co/WRHPzIsezr",
              "urls" : [ "https://t.co/r6DMzTfdvF" ],
              "mediaUrls" : [ "https://t.co/WRHPzIsezr", "https://t.co/WRHPzIsezr", "https://t.co/WRHPzIsezr" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "FILA",
              "screenName" : "@fila_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "13 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-08 02:00:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-08 02:01:30",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2020-11-08 02:01:32",
            "engagementType" : "EmbeddedMedia"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1322010883367735296",
              "tweetText" : "iPhone 12 Pro. Dolby Vision 방식으로 촬영하고 편집하는 유일한 카메라.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "스마트hdr"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "5.9mmthinipadpro"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "기술"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-11-08 02:00:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-08 03:59:50",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-11-08 03:59:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-08 18:57:08",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-08 18:54:11",
            "engagementType" : "VideoContent1secView"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1341192972935651329",
              "tweetText" : "#GO_BEYOND\n\n“Pokemon GO” GO BEYOND!\n칼로스지방의 포켓몬이 등장했습니다!\n선물과 포켓스톱을 확인하고\n몬스터볼을 준비하세요!✨\n\n#GOBEYOND #칼로스지방 #몬스터볼 \n#포켓몬 #포켓몬스터 #포켓몬고 #포켓몬GO",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76984",
              "name" : "#GO_BEYOND",
              "description" : "“Pokemon GO”에 #칼로스지방의 #포켓몬이 등장했습니다!  모두들 #몬스터볼을 준비하세요✨"
            },
            "advertiserInfo" : {
              "advertiserName" : "Pokémon GO Korea",
              "screenName" : "@pokemongoappko"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-25 03:43:16"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 04:47:52",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-25 03:47:17",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-25 03:47:23",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338997297485582353",
              "tweetText" : "[연말 특별★이벤트] \n한정수량으로 제작한 몬스터 에너지 2021 캘린더와 다양한 몬스터 에너지 아이템이 담긴 기프트박스 득템 기회!\n이벤트 바로가기&gt;&gt; https://t.co/OZ0IDyHTn2 https://t.co/17LKId0NHw",
              "urls" : [ "https://t.co/OZ0IDyHTn2" ],
              "mediaUrls" : [ "https://t.co/17LKId0NHw", "https://t.co/17LKId0NHw" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "캘린더"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            } ],
            "impressionTime" : "2020-12-25 03:43:19"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 03:43:20",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1341641200479047680",
              "tweetText" : "#갤럭시팬감동선물이벤트\n\n1,000분의 스마트폰 액정을 단돈 만원에 교체해 드려요💝\n\n자세한 사항은 삼성 멤버스를 통해 확인하세요!\n\n📌 기간: ~2021.01.06(수)\n\n📌 이벤트 확인하기\n\nhttps://t.co/5Ve4KCiq3x",
              "urls" : [ "https://t.co/5Ve4KCiq3x" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-24 18:15:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-24 18:15:43",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338997297485582353",
              "tweetText" : "[연말 특별★이벤트] \n한정수량으로 제작한 몬스터 에너지 2021 캘린더와 다양한 몬스터 에너지 아이템이 담긴 기프트박스 득템 기회!\n이벤트 바로가기&gt;&gt; https://t.co/OZ0IDyHTn2 https://t.co/17LKId0NHw",
              "urls" : [ "https://t.co/OZ0IDyHTn2" ],
              "mediaUrls" : [ "https://t.co/17LKId0NHw", "https://t.co/17LKId0NHw" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "캘린더"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            } ],
            "impressionTime" : "2020-12-24 18:15:44"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-24 18:15:45",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1338997297485582353",
              "tweetText" : "[연말 특별★이벤트] \n한정수량으로 제작한 몬스터 에너지 2021 캘린더와 다양한 몬스터 에너지 아이템이 담긴 기프트박스 득템 기회!\n이벤트 바로가기&gt;&gt; https://t.co/OZ0IDyHTn2 https://t.co/17LKId0NHw",
              "urls" : [ "https://t.co/OZ0IDyHTn2" ],
              "mediaUrls" : [ "https://t.co/17LKId0NHw", "https://t.co/17LKId0NHw" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "몬스터 에너지 코리아",
              "screenName" : "@MonsterEnergyKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "캘린더"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            } ],
            "impressionTime" : "2020-12-25 04:46:48"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 04:46:59",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1341988314497261570",
              "tweetText" : "🏆큐라프록스 골든디스크 리미티드 에디션🏆\n\n내 가수 칫솔은 내가 찾는다 🧐\n\n골든디스크 리미티드 에디션 굿즈\n지금 바로 큐라프록스에서 만나보세요!\n\n#큐라프록스 #큐라덴 #골든디스크 #골든디스크어워즈 https://t.co/d0hTkybZ6k",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/d0hTkybZ6k", "https://t.co/d0hTkybZ6k", "https://t.co/d0hTkybZ6k", "https://t.co/d0hTkybZ6k" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#KimSungkyu"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#뮤직뱅크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "한국 음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#스밍"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "티켓팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#인가"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이유(Iu) 공식 트위터"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "뮤직뱅크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "여자 친구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#엑소"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#티켓팅"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BLACKPINK"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "V (BTS)"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-25 04:46:48"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 04:47:03",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333351595036164096",
              "tweetText" : "아니 내가 이사까지 공부해야 돼?\n\n더 알아보기: https://t.co/iqQNd3PVEJ",
              "urls" : [ "https://t.co/iqQNd3PVEJ" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "짐싸",
              "screenName" : "@zimssa24"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-25 17:35:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-26 01:02:14",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-26 03:37:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-26 01:13:20",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-26 03:36:46",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1341713446983749634",
              "tweetText" : "집콕에는 쿠키런이 최고🏃‍♀️🏃‍♂️\n매일 출석만해도 크리스탈과💎 에픽쿠키 5종 보상을 드립니다!\n연말에는 쿠키런과 함께해요❤️\n\n#쿠키런 #쿠키런오븐브레이크",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "쿠키런 : 오븐브레이크",
              "screenName" : "@CookieRunKR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "엘소드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모두의마블"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "넥슨"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이템"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "배린이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "쿠키런"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아이러브커피"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "꿈의집"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "애니팡"
            }, {
              "targetingType" : "OS versions",
              "targetingValue" : "iOS 8.0 and above"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak ANDROID All"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "App open Cookie Run: OvenBreak IOS All"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-25 17:35:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 23:30:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-25 23:28:52",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-25 23:28:56",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-25 23:28:49",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340884511534432259",
              "tweetText" : "행운버거 먹으면 개당 100원이 아픈 환아들과 가족을 위한 RMHC 하우스에 자동 기부! 행운버거의 놀라운 힘 나누고 따뜻한 연말 보내자!\n#행운버거의_놀라운_힘\n#먹기만해도_기부되는_행운버거\n#컬리후라이도_돌아왔어요 https://t.co/qUpb74s8bq",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/qUpb74s8bq" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76991",
              "name" : "#행운버거의_놀라운_힘",
              "description" : "행운버거 먹으면 개당 100원 자동 기부!"
            },
            "advertiserInfo" : {
              "advertiserName" : "맥도날드(McDonald's)",
              "screenName" : "@KOR_McDonalds"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-25 17:35:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 17:42:25",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-25 17:50:53",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-25 23:23:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-25 23:15:39",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-25 23:15:30",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-25 23:15:42",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-25 17:38:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-25 17:42:21",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-25 17:36:14",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-25 23:15:43",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-25 23:15:43",
            "engagementType" : "VideoContentPlaybackComplete"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1333351595036164096",
              "tweetText" : "아니 내가 이사까지 공부해야 돼?\n\n더 알아보기: https://t.co/iqQNd3PVEJ",
              "urls" : [ "https://t.co/iqQNd3PVEJ" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "짐싸",
              "screenName" : "@zimssa24"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-25 17:35:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-25 23:27:31",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2020-12-25 23:30:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-25 23:27:35",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-25 23:27:28",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-12-25 23:27:29",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-12-25 23:27:32",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-12-25 23:27:25",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-25 23:27:29",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-12-25 23:27:38",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2020-12-25 23:27:28",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-25 23:27:29",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-12-25 23:27:39",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2020-12-25 23:27:39",
            "engagementType" : "VideoContentPlaybackComplete"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340910642971070465",
              "tweetText" : "새롭게 선보이는 iPhone 12",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-27 01:24:51"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-27 01:25:19",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-27 01:25:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-27 01:58:43",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911720701644800",
              "tweetText" : "반가워요 5G. iPhone 12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트 등"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "seoul museum of art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "지혜 큐빅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "현대적인 디자인"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "성균관대 학교"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "제주 박물관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인팅"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-27 10:01:25"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-27 10:14:29",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-27 10:01:27",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2020-12-27 10:01:32",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-27 10:14:24",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2020-12-27 10:10:15",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-27 10:01:28",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-12-27 10:01:30",
            "engagementType" : "VideoContentPlayback50"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911011390353409",
              "tweetText" : "새롭게 선보이는 iPhone 12. 모든 카메라에서 야간 모드 지원.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2020-12-28 10:34:50"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-28 10:39:37",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-28 10:39:50",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-12-28 10:35:37",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1336945655512588288",
              "tweetText" : "🔸큐라프록스 팝업스토어 일정 안내🔸\n\n골든디스크어워즈 리미티드 에디션의 실물 영접 기회👀\n식품관에서 큐라프록스 팝업스토어를 찾아주세요✔️\n#큐라덴 #큐라프록스 #팝업스토어 https://t.co/mS35titDln",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/mS35titDln", "https://t.co/mS35titDln", "https://t.co/mS35titDln" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "패션"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "쇼핑"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-29 10:04:41"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-29 10:04:42",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1341971355000922112",
              "tweetText" : "🏆큐라프록스 골든디스크 리미티드 에디션🏆\n\n이 칫솔의 주인공은 누구일까요? 👀\n내 가수와 어울리는 칫솔을 큐라프록스에서 만나보세요!\n👉 https://t.co/u6cRnwwIHZ\n\n*큐라프록스는 제35회 골든디스크어워즈의 메인 스폰서입니다.\n#큐라프록스 #큐라덴 #골든디스크어워즈 #골든디스크 https://t.co/7KOJXXMOCl",
              "urls" : [ "https://t.co/u6cRnwwIHZ" ],
              "mediaUrls" : [ "https://t.co/7KOJXXMOCl", "https://t.co/7KOJXXMOCl" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "큐라프록스 코리아",
              "screenName" : "@curaprox_korea"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Music festivals and concerts"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#카이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#싱글"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "소녀 시대"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "키노"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "마마무"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이하이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "싱글"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "모모랜드"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "워너원"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "최현석"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "Jang Keun Suk 장근석"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "V LIVE"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#이하이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#라이브"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#하루토"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "하루토"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#최현석"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#방탄소년단"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "한국 음악"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#블랙핑크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "#키노"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BLACKPINK"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "V (BTS)"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "BTS"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-12-30 03:51:35"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-12-30 03:51:35",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1343736600782520321",
              "tweetText" : "✨갤럭시 팬 트위터 RT 이벤트✨ \n#갤럭시팬감동선물이벤트\n\n한 번 갤럭시 유저는 영원한 갤럭시 유저~💝 \n갤럭시만 할 수 있는 팬 사랑을 소문내면, 추첨을 통해 아메리카노를 선물로 드려요! \n※ 참여방법 관련 자세한 내용 스레드 참고 https://t.co/QwKe1svPjR",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/QwKe1svPjR", "https://t.co/QwKe1svPjR", "https://t.co/QwKe1svPjR" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Galaxy S21 event",
              "screenName" : "@galaxys21event"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Device models",
              "targetingValue" : "iPhone 8"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-02 02:21:40"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-02 02:21:41",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1344184595420389378",
              "tweetText" : "[페이트/그랜드오더 신년 캠페인]\n\n2021년에도 FGO를 잘 부탁드립니다!\n성정석과 호부 등 푸짐한 선물 배포 중!\n지금 바로 페이트/그랜드 오더에 접속하세요.\n\n▶공식사이트 :  https://t.co/ngV9MN98Bc\n\n#페이트그랜드오더 #페그오 #한그오 #FGO\n#2021기념",
              "urls" : [ "https://t.co/ngV9MN98Bc" ],
              "mediaUrls" : [ ]
            },
            "promotedTrendInfo" : {
              "trendId" : "77209",
              "name" : "#FateGOKR20210102",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "페이트/그랜드 오더",
              "screenName" : "@FateGO_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-02 02:21:38"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-02 02:27:42",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-02 02:27:45",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1343822755515359233",
              "tweetText" : "페이트/그랜드오더 신년 캠페인 ▶\n\n새해 복 많이 받으세요~\n2021년 새해 기념 캠페인, 이벤트가 진/행/중!\n지금 바로 페이트/그랜드오더로 접/속!\n\n■ 공식사이트 :   https://t.co/ngV9MN98Bc    \n\n#페이트그랜드오더 #페그오 #한그오 #FGO\n#2021기념",
              "urls" : [ "https://t.co/ngV9MN98Bc" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "페이트/그랜드 오더",
              "screenName" : "@FateGO_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게임"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Fate/Zero"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Fate/Grand Order"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-04 06:54:31"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-04 06:54:32",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1325453027780800515",
              "tweetText" : "[#빅톤]\nVICTON 1ST FULL ALBUM PROLOGUE VIDEO\n\n▶ https://t.co/9GTFky1pRq\n\n2020.12.01 \n\n#VICTON #VOICE_The_future_is_now https://t.co/gfFugp9cWG",
              "urls" : [ "https://t.co/9GTFky1pRq" ],
              "mediaUrls" : [ "https://t.co/gfFugp9cWG" ]
            },
            "promotedTrendInfo" : {
              "trendId" : "76017",
              "name" : "#VICTON110920201109",
              "description" : ""
            },
            "advertiserInfo" : {
              "advertiserName" : "VICTON(빅톤)",
              "screenName" : "@VICTON1109"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-08 18:54:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-08 18:54:16",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2020-11-08 18:56:38",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2020-11-08 18:56:27",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2020-11-08 18:54:17",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2020-11-08 18:56:30",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2020-11-08 19:01:56",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-08 18:56:27",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2020-11-08 18:57:08",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2020-11-08 18:54:12",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1322047081477931008",
              "tweetText" : "Momo, the dancing machine of Twice. Nothing can stop you. \n\nKeep shining all the time, we will always stay with you🤟\n\nももりん誕生日おめでとう\n\n#MOMO #모모 #モモ #HAPPYMOMODAY\n#ももりんのたんじょーびん #TWICE #트와이스\n\nhttps://t.co/OsP6uCOdjJ https://t.co/9ECJF0DcYf",
              "urls" : [ "https://t.co/OsP6uCOdjJ" ],
              "mediaUrls" : [ "https://t.co/9ECJF0DcYf" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "K-POP AD 남일애드컴 南艺企划",
              "screenName" : "@k_pop_ad"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2020-11-08 18:54:13"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2020-11-08 18:54:14",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1324654910923661315",
              "tweetText" : "&lt;라온 X 가디언 테일즈&gt; 콜라보레이션!\n크.. 역시 갓겜에 어울리는 갓띵곡이네!",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "가디언 테일즈",
              "screenName" : "@TalesGuardian"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "App Activity",
              "targetingValue" : "Install 가디언 테일즈 IOS 7 Day"
            }, {
              "targetingType" : "App Activity",
              "targetingValue" : "Install 가디언 테일즈 ANDROID 7 Day"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-04 17:52:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-04 17:52:12",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340910768460496897",
              "tweetText" : "새롭게 선보이는 iPhone 12",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "halsey 팬 art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "서도호"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트 브러쉬"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "소낭구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아트 브 뤼케"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "haegue yang"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아트바바"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "online art & drawing"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-06 02:25:59"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-06 04:25:59",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-06 02:26:13",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-06 04:25:56",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-06 04:25:59",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-06 02:26:01",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-06 04:26:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-06 02:26:04",
            "engagementType" : "VideoContentPlayback25"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1343822945290862599",
              "tweetText" : "페이트/그랜드오더 신년 캠페인 ▶\n\n참새 여관에 어서 오세요!\n염마정의 여주인 ★5 베니엔마 전격 등장!\nFGO 신년 기념 이벤트&amp;픽업에서 만나보세요!\n\n■ 공식사이트 :   https://t.co/ngV9MN98Bc    \n\n#페이트그랜드오더 #페그오 #한그오 #FGO\n#2021기념",
              "urls" : [ "https://t.co/ngV9MN98Bc" ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "페이트/그랜드 오더",
              "screenName" : "@FateGO_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "#트라이건"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "하나 키미"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "절대 남자 친구"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "트라이건"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "루로 니 켄신"
            }, {
              "targetingType" : "Conversation topics",
              "targetingValue" : "Fate/Grand Order"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-05 23:54:01"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-05 23:54:02",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1306804368578981889",
              "tweetText" : "\"형님과 몸을 섞은 음인을 형수라 하지 않으면, 뭐라 불러야 하는지. 하하.\"\n\n음인인 기조는 황제에게 접객소의 노예를 취급받고 있는 와중에, 친왕은 그런 기조에게 '형수'라 부르며 조롱하는데..\n\n[나선몽] ⓒ ice\n무료회차 보러가기 ▶️ https://t.co/cnSOpnJu2e\n\n#BL #오메가버스 #집착공 #황제공 https://t.co/6CGsnwUCxh",
              "urls" : [ "https://t.co/cnSOpnJu2e" ],
              "mediaUrls" : [ "https://t.co/6CGsnwUCxh" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "봄툰_봄소설추천봇",
              "screenName" : "@BOM_NOVEL"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "봄툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "19금소설"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "바텀"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "단편선"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게이물"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "19금만화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "게이"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "완결"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "네이버웹툰"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "탑"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "공"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "수"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "다음웹툰"
            }, {
              "targetingType" : "Website Activity",
              "targetingValue" : "나선몽 조회자"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "21 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-05 23:32:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-05 23:32:58",
            "engagementType" : "Detail"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1344520921407578114",
              "tweetText" : "신규 직업 카인 1월 7일 업데이트 🏹\n어둠의 추격자, 카인 테마곡 〈Not Belong Anyone〉 선공개 📺\n\n#메이플스토리 #카인 #BewhY #MapleStory",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "메이플스토리",
              "screenName" : "@MapleStory_KR"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24959199"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 24990241"
            }, {
              "targetingType" : "Retargeting campaign engager",
              "targetingValue" : "Retargeting campaign engager: 25009153"
            }, {
              "targetingType" : "Retargeting engagement type",
              "targetingValue" : "Retargeting engagement type: 2"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-06 04:26:01"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-06 04:26:03",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-06 04:26:16",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1346643325877514240",
              "tweetText" : "이렇게 추울땐⛄️❄️매콤한 #땡초만두 로 뜨끈뜨끈 #떡만둣국 끓이는게 국룰이지😉\n\n#이벤트\n땡초만두 넣은 떡만둣국 먹고픈 사람~\nRT+답멘 남겨줘!👋\n\n5명 추첨 #라면보다_쉬운_떡만둣국 세트 선물!(당발 1/11)\n\n#풀무원\n#얇은피꽉찬속만두\n#사골곰탕\n#찰떡국떡 https://t.co/e7gP1WmeyP",
              "urls" : [ ],
              "mediaUrls" : [ "https://t.co/e7gP1WmeyP", "https://t.co/e7gP1WmeyP" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "얄피만두🥟",
              "screenName" : "@yalp_mandu"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "13 to 39 (Japan only)"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            } ],
            "impressionTime" : "2021-01-06 07:15:02"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-06 07:15:04",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347052846114426881",
              "tweetText" : "마침내 손에 넣은 아름답고 강력한 힘.\n당신의 든든한 조력자 스타더스트를 지금 만나보세요.\n\n마비노기 스타더스트 업데이트\n\n자세히 알아보기 ▶ https://t.co/SqHb3TOsYv https://t.co/bQ3a6eZMec",
              "urls" : [ "https://t.co/SqHb3TOsYv" ],
              "mediaUrls" : [ "https://t.co/bQ3a6eZMec" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-07 07:23:11"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-07 07:23:11",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2021-01-07 07:28:34",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-07 07:23:12",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-07 07:26:28",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-07 07:32:04",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "SearchTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1344266990194745346",
              "tweetText" : "“임신입니다.”\n하룻밤의 실수로 폭군의 아이를 가져 버렸다.\n\n[폭군의 아이를 가졌습니다] ©류란&amp;SF_JD/마루코믹스\n무료회차 보러가기 ▶https://t.co/gujCKr3st3\n\n#로맨스 #판타지 #궁정물 #육아 #집착남 #오직봄툰 https://t.co/0oVj5J6cwL",
              "urls" : [ "https://t.co/gujCKr3st3" ],
              "mediaUrls" : [ "https://t.co/0oVj5J6cwL", "https://t.co/0oVj5J6cwL", "https://t.co/0oVj5J6cwL", "https://t.co/0oVj5J6cwL" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "봄툰_작품추천봇",
              "screenName" : "@BOM_TOON"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "21 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            } ],
            "impressionTime" : "2021-01-07 08:15:05"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-07 08:15:15",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:43",
            "engagementType" : "Detail"
          }, {
            "engagementTime" : "2021-01-07 08:15:30",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:18",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:39",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:26",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:37",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:40",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:21",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:33",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:13",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:24",
            "engagementType" : "EmbeddedMedia"
          }, {
            "engagementTime" : "2021-01-07 08:15:27",
            "engagementType" : "EmbeddedMedia"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347060398516699138",
              "tweetText" : "🌟별빛을 모아 선물로 체인지🌟\n\n천문학회 꿈나무 애스트로를 도와\n차곡차곡 연구 포인트를 모아보세요.\n\n커피머신, Z플립, 아이패드까지\n성실한 밀레시안만이 가질 수 있는\n총 3천만원의 선물도 준비 완료 🎁\n\n자세히 보기▶https://t.co/cQd0chfjbp https://t.co/zJB9pGXuox",
              "urls" : [ "https://t.co/cQd0chfjbp" ],
              "mediaUrls" : [ "https://t.co/zJB9pGXuox" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-07 16:35:09"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-07 16:35:10",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1332132201861836800",
              "tweetText" : "13월 세금폭탄 무조건 피하는 꿀팁.toon\n연말정산 세금 토하고 억울해본 사람? 저요 🙋‍♀️\n이 툰 보면 혜택 뽕 뽑는 법 싹 가능",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "뱅크샐러드",
              "screenName" : "@banksalad"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-07 16:35:07"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-07 16:35:18",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-07 16:38:50",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1344180283436777473",
              "tweetText" : "우리집 고영이 더 좋아하는 짐싸",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "짐싸",
              "screenName" : "@zimssa24"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Age",
              "targetingValue" : "25 to 49"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-07 17:21:39"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-07 17:21:54",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-07 17:21:40",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2021-01-07 17:21:46",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-07 17:21:40",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-07 17:21:43",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-07 17:29:17",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-07 17:21:51",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-07 17:21:54",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-07 17:21:54",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-07 17:23:31",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-07 17:21:43",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-07 17:21:47",
            "engagementType" : "VideoContentPlayback50"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347060398516699138",
              "tweetText" : "🌟별빛을 모아 선물로 체인지🌟\n\n천문학회 꿈나무 애스트로를 도와\n차곡차곡 연구 포인트를 모아보세요.\n\n커피머신, Z플립, 아이패드까지\n성실한 밀레시안만이 가질 수 있는\n총 3천만원의 선물도 준비 완료 🎁\n\n자세히 보기▶https://t.co/cQd0chfjbp https://t.co/zJB9pGXuox",
              "urls" : [ "https://t.co/cQd0chfjbp" ],
              "mediaUrls" : [ "https://t.co/zJB9pGXuox" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-10 17:43:12"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-10 17:43:14",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911459778220033",
              "tweetText" : "덤벙도 오케이. 첨벙도 오케이. iPhone12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "artpremium magazine"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "재건에"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art baba"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "디자인"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고프니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "박서보"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이중섭 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "호암 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술의 전당"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "video course"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "visual art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "서울 시립 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스케치"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스테인드 글라스 모자이크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "kim hyunjung"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "korea art platform"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "iaaf seoul art faire"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "벙커 드 뤼미에르"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "bra kojoe"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-11 10:58:43"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-11 10:59:03",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-11 10:59:33",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-11 10:59:33",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-11 10:59:03",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-11 11:41:03",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-11 10:59:33",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-11 11:07:33",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-11 10:59:30",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-11 10:59:32",
            "engagementType" : "VideoContentPlayback75"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347052846114426881",
              "tweetText" : "마침내 손에 넣은 아름답고 강력한 힘.\n당신의 든든한 조력자 스타더스트를 지금 만나보세요.\n\n마비노기 스타더스트 업데이트\n\n자세히 알아보기 ▶ https://t.co/SqHb3TOsYv https://t.co/bQ3a6eZMec",
              "urls" : [ "https://t.co/SqHb3TOsYv" ],
              "mediaUrls" : [ "https://t.co/bQ3a6eZMec" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-11 10:59:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-11 11:07:33",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-11 10:59:05",
            "engagementType" : "ChargeableImpression"
          }, {
            "engagementTime" : "2021-01-11 10:59:06",
            "engagementType" : "VideoContentPlaybackStart"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911459778220033",
              "tweetText" : "덤벙도 오케이. 첨벙도 오케이. iPhone12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "iaaf seoul art faire"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "korea art platform"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이중섭 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "고프니"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "kim hyunjung"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "박서보"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "visual art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "서울 시립 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술의 전당"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "디자인"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "호암 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스테인드 글라스 모자이크"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "스케치"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "아크릴 페인팅"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art baba"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "미술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "벙커 드 뤼미에르"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "삽화"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "video course"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "artpremium magazine"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "재건에"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "페인트"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "bra kojoe"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-11 08:25:42"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-11 09:14:11",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-11 09:14:14",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-11 09:14:09",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-11 09:14:14",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-11 09:14:12",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-11 09:14:23",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-11 09:14:13",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-11 09:14:14",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-11 09:14:15",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-11 09:14:10",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-11 11:07:33",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347052846114426881",
              "tweetText" : "마침내 손에 넣은 아름답고 강력한 힘.\n당신의 든든한 조력자 스타더스트를 지금 만나보세요.\n\n마비노기 스타더스트 업데이트\n\n자세히 알아보기 ▶ https://t.co/SqHb3TOsYv https://t.co/bQ3a6eZMec",
              "urls" : [ "https://t.co/SqHb3TOsYv" ],
              "mediaUrls" : [ "https://t.co/bQ3a6eZMec" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Online gaming"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-11 04:49:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-11 04:49:04",
            "engagementType" : "ChargeableImpression"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340988962366607361",
              "tweetText" : "새롭게 선보이는 iPhone 12. 5G. A14 Bionic 칩. 새로운 디자인. Super Retina XDR 디스플레이. Ceramic Shield. 모든 카메라에서 야간 모드 지원. 그리고 새로운 방식으로 액세서리를 붙이는 MagSafe.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-12 03:33:48"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-12 03:34:02",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-12 03:34:04",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-12 03:33:58",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-12 03:35:11",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-12 03:34:04",
            "engagementType" : "CarouselSwipeNext"
          }, {
            "engagementTime" : "2021-01-12 03:34:03",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-12 04:19:06",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-12 03:33:56",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-12 04:19:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 03:34:00",
            "engagementType" : "VideoContentViewThreshold"
          }, {
            "engagementTime" : "2021-01-12 04:19:05",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-12 03:35:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 03:35:13",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-12 04:19:49",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 03:34:00",
            "engagementType" : "VideoContentViewV2"
          }, {
            "engagementTime" : "2021-01-12 03:33:59",
            "engagementType" : "VideoContentMrcView"
          }, {
            "engagementTime" : "2021-01-12 04:19:09",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 04:19:06",
            "engagementType" : "VideoContent6secView"
          }, {
            "engagementTime" : "2021-01-12 03:34:05",
            "engagementType" : "VideoContent1secView"
          }, {
            "engagementTime" : "2021-01-12 03:34:05",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-12 03:33:59",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-12 03:35:38",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 04:19:06",
            "engagementType" : "VideoContentShortFormComplete"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911096031367168",
              "tweetText" : "새롭게 선보이는 iPhone 12. 모든 카메라에서 야간 모드 지원.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "예술의 전당"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "벙커 드 뤼미에르"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "서울 시립 미술관"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "이불"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "art"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "iaaf seoul art faire"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "오늘의풍경"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "그림"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "artpremium magazine"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "박서보"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "디자인"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "예술적 기술"
            }, {
              "targetingType" : "Keywords",
              "targetingValue" : "조각품"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-12 10:20:56"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-12 10:21:29",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-12 10:21:29",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-12 10:25:09",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "adEngagements" : {
        "engagements" : [ {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911702498443264",
              "tweetText" : "반가워요 5G. iPhone 12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "breads"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-12 17:26:15"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-13 03:28:37",
            "engagementType" : "VideoSession"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "ProfileTweets",
            "promotedTweetInfo" : {
              "tweetId" : "1347045296514195457",
              "tweetText" : "전장을 지배할 아름다운 별빛.\n선택받은 자에게만 주어지는 별의 힘을\n지금 바로 경험하세요\n\n마비노기 스타더스트 업데이트\n\n지금 알아보기▶https://t.co/sDU278bfOV https://t.co/yHVdM6EshX",
              "urls" : [ "https://t.co/sDU278bfOV" ],
              "mediaUrls" : [ "https://t.co/yHVdM6EshX" ]
            },
            "advertiserInfo" : {
              "advertiserName" : "마비노기",
              "screenName" : "@Nexon_Mabinogi"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 to 34"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-12 17:27:04"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-12 17:27:04",
            "engagementType" : "ChargeableImpression"
          } ]
        }, {
          "impressionAttributes" : {
            "deviceInfo" : {
              "osType" : "Ios",
              "deviceId" : "RLH4klKWWmi3OxyZ1DXEWYhdtcllfGCQjboVv62rRSo="
            },
            "displayLocation" : "TimelineHome",
            "promotedTweetInfo" : {
              "tweetId" : "1340911702498443264",
              "tweetText" : "반가워요 5G. iPhone 12.",
              "urls" : [ ],
              "mediaUrls" : [ ]
            },
            "advertiserInfo" : {
              "advertiserName" : "Apple",
              "screenName" : "@Apple"
            },
            "matchedTargetingCriteria" : [ {
              "targetingType" : "Keywords",
              "targetingValue" : "breads"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Console gaming"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Tech news"
            }, {
              "targetingType" : "Interests",
              "targetingValue" : "Gaming news and general info"
            }, {
              "targetingType" : "Age",
              "targetingValue" : "18 and up"
            }, {
              "targetingType" : "Languages",
              "targetingValue" : "Korean"
            }, {
              "targetingType" : "Locations",
              "targetingValue" : "South Korea"
            }, {
              "targetingType" : "Platforms",
              "targetingValue" : "iOS"
            } ],
            "impressionTime" : "2021-01-12 17:26:15"
          },
          "engagementAttributes" : [ {
            "engagementTime" : "2021-01-12 17:39:02",
            "engagementType" : "VideoContentPlayback25"
          }, {
            "engagementTime" : "2021-01-12 17:27:14",
            "engagementType" : "VideoContentPlaybackStart"
          }, {
            "engagementTime" : "2021-01-12 17:39:03",
            "engagementType" : "VideoContentPlayback50"
          }, {
            "engagementTime" : "2021-01-12 17:39:06",
            "engagementType" : "VideoContentPlayback95"
          }, {
            "engagementTime" : "2021-01-12 21:59:25",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 23:09:18",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 17:39:06",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-12 17:39:05",
            "engagementType" : "VideoContentPlayback75"
          }, {
            "engagementTime" : "2021-01-12 17:31:16",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 17:39:06",
            "engagementType" : "VideoContentPlaybackComplete"
          }, {
            "engagementTime" : "2021-01-12 21:59:11",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 17:46:12",
            "engagementType" : "VideoSession"
          }, {
            "engagementTime" : "2021-01-12 23:09:07",
            "engagementType" : "VideoContentShortFormComplete"
          }, {
            "engagementTime" : "2021-01-12 23:12:56",
            "engagementType" : "VideoSession"
          } ]
        } ]
      }
    }
  }
} ]