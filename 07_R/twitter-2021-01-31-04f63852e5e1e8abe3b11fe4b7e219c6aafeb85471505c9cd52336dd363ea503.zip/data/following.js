window.YTD.following.part0 = [ {
  "following" : {
    "accountId" : "1185809698080997376",
    "userLink" : "https://twitter.com/intent/user?user_id=1185809698080997376"
  }
}, {
  "following" : {
    "accountId" : "1171737324666798080",
    "userLink" : "https://twitter.com/intent/user?user_id=1171737324666798080"
  }
}, {
  "following" : {
    "accountId" : "1205051640878751744",
    "userLink" : "https://twitter.com/intent/user?user_id=1205051640878751744"
  }
}, {
  "following" : {
    "accountId" : "2755120298",
    "userLink" : "https://twitter.com/intent/user?user_id=2755120298"
  }
} ]