window.YTD.ad_mobile_conversions_unattributed.part0 = [ {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "쿠팡 - Coupang",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-07 00:30:19"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Karrot - Buy & sell locally",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-07 00:29:25"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-12 12:08:42"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "야놀자",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-13 00:02:58"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "content_view",
          "applicationName" : "야놀자",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-13 00:07:08",
          "additionalParameters" : {
            "currency" : "N/A"
          }
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-12 21:58:49"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-14 23:20:28"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-15 05:22:52"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Naver Papago - AI Translator",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-15 15:38:37"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "sign_up",
          "applicationName" : "모바일증권 나무(계좌개설 겸용)",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-25 02:24:38",
          "additionalParameters" : {
            "currency" : "N/A"
          }
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "install",
          "applicationName" : "모바일증권 나무(계좌개설 겸용)",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-25 01:32:05"
        } ]
      }
    }
  }
}, {
  "ad" : {
    "adsUserData" : {
      "unattributedMobileAppConversions" : {
        "conversions" : [ {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-25 17:15:34"
        }, {
          "mobilePlatform" : "Ios",
          "conversionEvent" : "re_engage",
          "applicationName" : "Twitter",
          "conversionValue" : "0",
          "conversionTime" : "2021-01-25 23:21:37"
        } ]
      }
    }
  }
} ]