window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "768730636148367360",
    "verified" : false
  }
} ]