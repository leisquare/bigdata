window.YTD.email_address_change.part0 = [ {
  "emailAddressChange" : {
    "accountId" : "768730636148367360",
    "emailChange" : {
      "changedAt" : "2016-08-25T08:52:53.000Z",
      "changedFrom" : "",
      "changedTo" : "abeltaunsent+25@gmail.com"
    }
  }
} ]