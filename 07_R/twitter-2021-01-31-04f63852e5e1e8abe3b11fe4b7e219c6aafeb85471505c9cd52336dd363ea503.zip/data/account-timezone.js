window.YTD.account_timezone.part0 = [ {
  "accountTimezone" : {
    "accountId" : "768730636148367360"
  }
} ]