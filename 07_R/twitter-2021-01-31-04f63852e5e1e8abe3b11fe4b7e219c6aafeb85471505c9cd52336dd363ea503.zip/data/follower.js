window.YTD.follower.part0 = [ {
  "follower" : {
    "accountId" : "1185809698080997376",
    "userLink" : "https://twitter.com/intent/user?user_id=1185809698080997376"
  }
}, {
  "follower" : {
    "accountId" : "2755120298",
    "userLink" : "https://twitter.com/intent/user?user_id=2755120298"
  }
}, {
  "follower" : {
    "accountId" : "1205051640878751744",
    "userLink" : "https://twitter.com/intent/user?user_id=1205051640878751744"
  }
} ]