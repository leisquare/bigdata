window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "티알자캐이야기를 거의 졈처럼 하는 계정",
      "website" : "",
      "location" : ""
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1243642877495910404/aLSHbBpJ.jpg"
  }
} ]