window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter",
      "url" : ""
    },
    "name" : "Twitter for iPhone",
    "description" : "Twitter for iPhone",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2021-01-06T02:25:58.000Z",
    "id" : "129032"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Privatter",
      "url" : "https://privatter.net/"
    },
    "name" : "Privatter（ぷらいべったー）",
    "description" : "Twitterのアカウントを使ってフォロワーにだけ見られるテキストや画像を公開できるツールです。",
    "permissions" : [ "read" ],
    "approvedAt" : "2021-01-19T17:05:40.000Z",
    "id" : "4002939"
  }
} ]