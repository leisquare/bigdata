window.YTD.mute.part0 = [ {
  "muting" : {
    "accountId" : "1185809698080997376",
    "userLink" : "https://twitter.com/intent/user?user_id=1185809698080997376"
  }
}, {
  "muting" : {
    "accountId" : "444465942",
    "userLink" : "https://twitter.com/intent/user?user_id=444465942"
  }
}, {
  "muting" : {
    "accountId" : "48284537",
    "userLink" : "https://twitter.com/intent/user?user_id=48284537"
  }
}, {
  "muting" : {
    "accountId" : "2390107598",
    "userLink" : "https://twitter.com/intent/user?user_id=2390107598"
  }
}, {
  "muting" : {
    "accountId" : "48661131",
    "userLink" : "https://twitter.com/intent/user?user_id=48661131"
  }
}, {
  "muting" : {
    "accountId" : "111236027",
    "userLink" : "https://twitter.com/intent/user?user_id=111236027"
  }
}, {
  "muting" : {
    "accountId" : "169000068",
    "userLink" : "https://twitter.com/intent/user?user_id=169000068"
  }
}, {
  "muting" : {
    "accountId" : "59686991",
    "userLink" : "https://twitter.com/intent/user?user_id=59686991"
  }
}, {
  "muting" : {
    "accountId" : "867990237804249099",
    "userLink" : "https://twitter.com/intent/user?user_id=867990237804249099"
  }
}, {
  "muting" : {
    "accountId" : "1152949452103045120",
    "userLink" : "https://twitter.com/intent/user?user_id=1152949452103045120"
  }
} ]