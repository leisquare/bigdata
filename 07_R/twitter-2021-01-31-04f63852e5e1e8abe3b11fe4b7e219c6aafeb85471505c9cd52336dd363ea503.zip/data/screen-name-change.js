window.YTD.screen_name_change.part0 = [ {
  "screenNameChange" : {
    "accountId" : "768730636148367360",
    "screenNameChange" : {
      "changedAt" : "2016-08-25T08:52:29.000Z",
      "changedFrom" : "abeltaunsent",
      "changedTo" : "Askr_shephar"
    }
  }
}, {
  "screenNameChange" : {
    "accountId" : "768730636148367360",
    "screenNameChange" : {
      "changedAt" : "2020-03-27T20:39:58.000Z",
      "changedFrom" : "Askr_shephar",
      "changedTo" : "nectardor"
    }
  }
} ]