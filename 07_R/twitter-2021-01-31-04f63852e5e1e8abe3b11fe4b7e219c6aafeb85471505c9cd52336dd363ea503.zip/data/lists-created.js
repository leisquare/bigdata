window.YTD.lists_created.part0 = [ {
  "userListInfo" : {
    "url" : "https://twitter.com/nectardor/lists/list-56655"
  }
} ]