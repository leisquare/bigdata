window.YTD.block.part0 = [ {
  "blocking" : {
    "accountId" : "1331844803307290626",
    "userLink" : "https://twitter.com/intent/user?user_id=1331844803307290626"
  }
}, {
  "blocking" : {
    "accountId" : "1152949452103045120",
    "userLink" : "https://twitter.com/intent/user?user_id=1152949452103045120"
  }
} ]