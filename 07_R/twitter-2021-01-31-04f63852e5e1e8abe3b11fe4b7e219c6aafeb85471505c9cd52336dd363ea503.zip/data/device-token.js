window.YTD.device_token.part0 = [ {
  "deviceToken" : {
    "clientApplicationId" : "-1",
    "token" : "B6J0SG09upVJNUguYFBSV7L4ths6E9QAP5uFeYAG",
    "createdAt" : "1970-01-01T00:00:00.000Z",
    "lastSeenAt" : "2020-08-05T08:19:44.742Z",
    "clientApplicationName" : ""
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "t5mckpZUfMXruxJygDC1GVNBAfIDhKdTEcmaI2Tt",
    "createdAt" : "2020-08-07T08:39:19.249Z",
    "lastSeenAt" : "2020-08-07T08:39:19.251Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "Bi1CNZixGMT6D74PAwrWPXii94xYOobmLmoMtXHG",
    "createdAt" : "2020-08-07T18:02:23.456Z",
    "lastSeenAt" : "2020-08-07T18:02:23.458Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "wtX93TwZQkTSuOU524sQkC1UEcU67nbg5vhNMFG5",
    "createdAt" : "2020-08-15T04:46:18.018Z",
    "lastSeenAt" : "2020-08-15T04:46:18.020Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "-1",
    "token" : "pz3cS79hEvJlMEk6Dk2zn19MVoXyZyjzy0Yl5yVA",
    "createdAt" : "1970-01-01T00:00:00.000Z",
    "lastSeenAt" : "2020-08-19T18:48:31.388Z",
    "clientApplicationName" : ""
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "29S4vEfmBHek7DjX0TaGuxBXnJhct4NCtaE0NnMr",
    "createdAt" : "2020-08-20T06:54:01.024Z",
    "lastSeenAt" : "2020-08-20T06:54:01.026Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "cMNuPziyOIIP38Bl90lwJ5ioNfD1XDokSUXdFli3",
    "createdAt" : "2020-08-25T15:56:04.892Z",
    "lastSeenAt" : "2020-08-25T15:56:04.895Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "7fWNdDgdPVTXo4tnlF3o2gxIKG5STaDYCSat8o3n",
    "createdAt" : "2020-09-04T02:00:26.446Z",
    "lastSeenAt" : "2020-09-04T02:00:26.448Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "VLp3X6HDUGclREppcxMpj5izsPSLj0eVuTBAY9kh",
    "createdAt" : "2020-09-05T18:07:47.874Z",
    "lastSeenAt" : "2020-09-05T18:07:47.876Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "GVdlKlQRd3TysZyf2ByQb6FGCp6qbDcLreENxpZF",
    "createdAt" : "2020-09-08T19:26:35.847Z",
    "lastSeenAt" : "2020-09-08T19:26:35.849Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "HXT2v1wBmsZ67iNTZDNIYynPBVXfwPTs2YSdPmRw",
    "createdAt" : "2020-09-11T07:48:25.573Z",
    "lastSeenAt" : "2020-09-11T07:48:25.574Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "wyKDpTZYrNV1a9Dp3E2C6newTEOU5LvHz61vOPdu",
    "createdAt" : "2020-09-13T19:21:29.582Z",
    "lastSeenAt" : "2020-09-13T19:21:29.584Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "xmmegGzgN38gWq5wi2EF2pcQGxEWLvpJBeWATvTy",
    "createdAt" : "2020-09-20T13:52:02.987Z",
    "lastSeenAt" : "2020-09-20T13:52:02.989Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "Wr72ILXPGDqxBcrivW7U6TlhIvI821hEw2LIZpMA",
    "createdAt" : "2020-09-30T16:47:11.242Z",
    "lastSeenAt" : "2020-09-30T16:47:11.244Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "mZLTsMh3eQrAvn9QiEPny2Hq3GIFSUftDWtLHBP3",
    "createdAt" : "2020-10-05T19:39:10.194Z",
    "lastSeenAt" : "2020-10-05T19:39:10.196Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "vrB5cTEiwXvhl1QszFytvwqqXZlUxZCYy6BiIxqK",
    "createdAt" : "2020-10-06T19:17:19.588Z",
    "lastSeenAt" : "2020-10-06T19:17:19.590Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "PKDy1CRZR4qAKJZ4xx2B02Mdn2gRALcXjgb28QqZ",
    "createdAt" : "2020-10-08T10:42:46.729Z",
    "lastSeenAt" : "2020-10-08T10:42:46.730Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "j1kCJq78B5LSOqHWgmXmfNWgjxCZM7XTQN0qXzyu",
    "createdAt" : "2020-10-16T18:02:35.614Z",
    "lastSeenAt" : "2020-10-16T18:02:35.616Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "T06uP2wR0ipl6G8Lzv0GneUJo0Tbt13W8p9ILjeL",
    "createdAt" : "2020-11-09T07:00:42.242Z",
    "lastSeenAt" : "2020-11-09T07:00:42.244Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "zxl4tfocz1ONEpfFqhk5S1stc3eyVKxl8BVwAZOB",
    "createdAt" : "2020-11-17T12:43:51.060Z",
    "lastSeenAt" : "2020-11-17T12:43:51.062Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "49152",
    "token" : "GTHQp5qJu7c3g2yL7sktZKQOAQ1Vc9HBIenY3Zgh",
    "createdAt" : "2020-08-23T03:21:05.247Z",
    "lastSeenAt" : "2020-12-08T23:04:30.881Z",
    "clientApplicationName" : "Mobile Web (Twitter)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "KMAgfE628rUqZl3GZ6QsvevG9CYWSJkZP5kVPiVK",
    "createdAt" : "2021-01-06T00:16:00.375Z",
    "lastSeenAt" : "2021-01-06T00:28:34.059Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "-1",
    "token" : "zRMus0fbQvQsgN3UD6euVjOQROhU2DVM4kGWzNio",
    "createdAt" : "1970-01-01T00:00:00.000Z",
    "lastSeenAt" : "2021-01-06T02:25:58.503Z",
    "clientApplicationName" : ""
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "2cvvAnlX2rpAnfHPJ2P4ueDnbmxLHXcPiJpPGTfh",
    "createdAt" : "2021-01-12T00:11:40.755Z",
    "lastSeenAt" : "2021-01-28T02:37:29.886Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
}, {
  "deviceToken" : {
    "clientApplicationId" : "3033300",
    "token" : "UtGAvwq7SBc4zM8gADZvaUm5cW1kRHEdADub4ddV",
    "createdAt" : "2021-01-06T11:46:14.944Z",
    "lastSeenAt" : "2021-01-30T16:20:02.431Z",
    "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
  }
} ]