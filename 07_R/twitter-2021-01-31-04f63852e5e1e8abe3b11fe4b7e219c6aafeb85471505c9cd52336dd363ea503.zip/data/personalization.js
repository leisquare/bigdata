window.YTD.personalization.part0 = [ {
  "p13nData" : {
    "demographics" : {
      "languages" : [ {
        "language" : "Korean",
        "isDisabled" : false
      }, {
        "language" : "Japanese",
        "isDisabled" : false
      }, {
        "language" : "English",
        "isDisabled" : false
      } ],
      "genderInfo" : {
        "gender" : "male"
      }
    },
    "interests" : {
      "interests" : [ {
        "name" : "2D animation",
        "isDisabled" : false
      }, {
        "name" : "AB6IX",
        "isDisabled" : false
      }, {
        "name" : "Accessories",
        "isDisabled" : false
      }, {
        "name" : "Adventure travel",
        "isDisabled" : false
      }, {
        "name" : "Amazon",
        "isDisabled" : false
      }, {
        "name" : "Animal Crossing",
        "isDisabled" : false
      }, {
        "name" : "Animal Crossing New Horizons",
        "isDisabled" : false
      }, {
        "name" : "Animals",
        "isDisabled" : false
      }, {
        "name" : "Animation",
        "isDisabled" : false
      }, {
        "name" : "Animation software",
        "isDisabled" : false
      }, {
        "name" : "Anime",
        "isDisabled" : false
      }, {
        "name" : "Apple",
        "isDisabled" : false
      }, {
        "name" : "Arashi",
        "isDisabled" : false
      }, {
        "name" : "Art",
        "isDisabled" : false
      }, {
        "name" : "Arts & culture",
        "isDisabled" : false
      }, {
        "name" : "Athletic apparel",
        "isDisabled" : false
      }, {
        "name" : "Automotive",
        "isDisabled" : false
      }, {
        "name" : "BLACKPINK",
        "isDisabled" : false
      }, {
        "name" : "BLEACH",
        "isDisabled" : false
      }, {
        "name" : "BTS",
        "isDisabled" : false
      }, {
        "name" : "Baek Jongwon",
        "isDisabled" : false
      }, {
        "name" : "Balenciaga",
        "isDisabled" : false
      }, {
        "name" : "Beauty",
        "isDisabled" : false
      }, {
        "name" : "Biology",
        "isDisabled" : false
      }, {
        "name" : "Bitcoin cryptocurrency",
        "isDisabled" : false
      }, {
        "name" : "Blade & Soul",
        "isDisabled" : false
      }, {
        "name" : "Books",
        "isDisabled" : false
      }, {
        "name" : "Books",
        "isDisabled" : false
      }, {
        "name" : "Books",
        "isDisabled" : false
      }, {
        "name" : "Boxing",
        "isDisabled" : false
      }, {
        "name" : "Brunch",
        "isDisabled" : false
      }, {
        "name" : "Business & finance",
        "isDisabled" : false
      }, {
        "name" : "CL",
        "isDisabled" : false
      }, {
        "name" : "COVID-19",
        "isDisabled" : false
      }, {
        "name" : "Cake",
        "isDisabled" : false
      }, {
        "name" : "Cats",
        "isDisabled" : false
      }, {
        "name" : "Celebrities",
        "isDisabled" : false
      }, {
        "name" : "Celebrity",
        "isDisabled" : false
      }, {
        "name" : "Chemistry",
        "isDisabled" : false
      }, {
        "name" : "Chess",
        "isDisabled" : false
      }, {
        "name" : "Chicken",
        "isDisabled" : false
      }, {
        "name" : "Chinese cuisine",
        "isDisabled" : false
      }, {
        "name" : "Climate change",
        "isDisabled" : false
      }, {
        "name" : "Coffee",
        "isDisabled" : false
      }, {
        "name" : "Collectibles",
        "isDisabled" : false
      }, {
        "name" : "College life",
        "isDisabled" : false
      }, {
        "name" : "Combat sports",
        "isDisabled" : false
      }, {
        "name" : "Comics",
        "isDisabled" : false
      }, {
        "name" : "Cookie Run",
        "isDisabled" : false
      }, {
        "name" : "Cookies",
        "isDisabled" : false
      }, {
        "name" : "Cosplay",
        "isDisabled" : false
      }, {
        "name" : "Cryptocurrencies",
        "isDisabled" : false
      }, {
        "name" : "Cuisines",
        "isDisabled" : false
      }, {
        "name" : "Cyphers",
        "isDisabled" : false
      }, {
        "name" : "Dark Souls",
        "isDisabled" : false
      }, {
        "name" : "Designer fashion",
        "isDisabled" : false
      }, {
        "name" : "Desserts and baked goods",
        "isDisabled" : false
      }, {
        "name" : "Digital creators",
        "isDisabled" : false
      }, {
        "name" : "Dior",
        "isDisabled" : false
      }, {
        "name" : "Disney",
        "isDisabled" : false
      }, {
        "name" : "Dogs",
        "isDisabled" : false
      }, {
        "name" : "Drawing & illustration",
        "isDisabled" : false
      }, {
        "name" : "Dresses",
        "isDisabled" : false
      }, {
        "name" : "Drinks",
        "isDisabled" : false
      }, {
        "name" : "Drums",
        "isDisabled" : false
      }, {
        "name" : "Dungeons & Dragons",
        "isDisabled" : false
      }, {
        "name" : "EXO",
        "isDisabled" : false
      }, {
        "name" : "Education",
        "isDisabled" : false
      }, {
        "name" : "Elsword",
        "isDisabled" : false
      }, {
        "name" : "Energy Drinks",
        "isDisabled" : false
      }, {
        "name" : "Ensemble Stars!",
        "isDisabled" : false
      }, {
        "name" : "Entertainment",
        "isDisabled" : false
      }, {
        "name" : "Entertainment franchises",
        "isDisabled" : false
      }, {
        "name" : "Entertainment industry",
        "isDisabled" : false
      }, {
        "name" : "Epic Games",
        "isDisabled" : false
      }, {
        "name" : "Epic Seven",
        "isDisabled" : false
      }, {
        "name" : "Esports",
        "isDisabled" : false
      }, {
        "name" : "Esports leagues",
        "isDisabled" : false
      }, {
        "name" : "FIFA",
        "isDisabled" : false
      }, {
        "name" : "Family",
        "isDisabled" : false
      }, {
        "name" : "Fashion",
        "isDisabled" : false
      }, {
        "name" : "Fashion & beauty",
        "isDisabled" : false
      }, {
        "name" : "Fashion models",
        "isDisabled" : false
      }, {
        "name" : "Fast food",
        "isDisabled" : false
      }, {
        "name" : "Fate/Grand Order",
        "isDisabled" : false
      }, {
        "name" : "Fate/stay night",
        "isDisabled" : false
      }, {
        "name" : "Fighting games",
        "isDisabled" : false
      }, {
        "name" : "Fila",
        "isDisabled" : false
      }, {
        "name" : "Final Fantasy",
        "isDisabled" : false
      }, {
        "name" : "Fine Dining",
        "isDisabled" : false
      }, {
        "name" : "Fitness",
        "isDisabled" : false
      }, {
        "name" : "Food",
        "isDisabled" : false
      }, {
        "name" : "Food",
        "isDisabled" : false
      }, {
        "name" : "Food inspiration",
        "isDisabled" : false
      }, {
        "name" : "GOT7",
        "isDisabled" : false
      }, {
        "name" : "Game development",
        "isDisabled" : false
      }, {
        "name" : "Games",
        "isDisabled" : false
      }, {
        "name" : "Gaming",
        "isDisabled" : false
      }, {
        "name" : "Gaming",
        "isDisabled" : false
      }, {
        "name" : "Gaming consoles",
        "isDisabled" : false
      }, {
        "name" : "Gaming news",
        "isDisabled" : false
      }, {
        "name" : "Gang Dongwon",
        "isDisabled" : false
      }, {
        "name" : "Google",
        "isDisabled" : false
      }, {
        "name" : "Graduate school",
        "isDisabled" : false
      }, {
        "name" : "Grand Theft Auto",
        "isDisabled" : false
      }, {
        "name" : "Guitar",
        "isDisabled" : false
      }, {
        "name" : "Halloween",
        "isDisabled" : false
      }, {
        "name" : "Harry Potter",
        "isDisabled" : false
      }, {
        "name" : "Hiking",
        "isDisabled" : false
      }, {
        "name" : "Hip hop",
        "isDisabled" : false
      }, {
        "name" : "Hiroaki Hirata",
        "isDisabled" : false
      }, {
        "name" : "Home & family",
        "isDisabled" : false
      }, {
        "name" : "Horoscope",
        "isDisabled" : false
      }, {
        "name" : "Horror films",
        "isDisabled" : false
      }, {
        "name" : "Hotel/Motel",
        "isDisabled" : false
      }, {
        "name" : "Huawei",
        "isDisabled" : false
      }, {
        "name" : "Hypnosismic",
        "isDisabled" : false
      }, {
        "name" : "Ice Cream",
        "isDisabled" : false
      }, {
        "name" : "Instagram",
        "isDisabled" : false
      }, {
        "name" : "Inuyasha",
        "isDisabled" : false
      }, {
        "name" : "Iphone 12",
        "isDisabled" : false
      }, {
        "name" : "J-pop",
        "isDisabled" : false
      }, {
        "name" : "Jewelry",
        "isDisabled" : false
      }, {
        "name" : "Jimin",
        "isDisabled" : false
      }, {
        "name" : "Jin",
        "isDisabled" : false
      }, {
        "name" : "Jung Woosung",
        "isDisabled" : false
      }, {
        "name" : "Jungkook",
        "isDisabled" : false
      }, {
        "name" : "K-hip hop",
        "isDisabled" : false
      }, {
        "name" : "K-pop",
        "isDisabled" : false
      }, {
        "name" : "KBO",
        "isDisabled" : false
      }, {
        "name" : "KFC",
        "isDisabled" : false
      }, {
        "name" : "KIA 타이거즈 (KIA Tigers)",
        "isDisabled" : false
      }, {
        "name" : "Kang Daniel",
        "isDisabled" : false
      }, {
        "name" : "Kim Hyesoo",
        "isDisabled" : false
      }, {
        "name" : "Kim Taeri",
        "isDisabled" : false
      }, {
        "name" : "Lee Daehwi",
        "isDisabled" : false
      }, {
        "name" : "Lee Youngja",
        "isDisabled" : false
      }, {
        "name" : "Liquor and spirits",
        "isDisabled" : false
      }, {
        "name" : "Literature",
        "isDisabled" : false
      }, {
        "name" : "Lord of the Rings",
        "isDisabled" : false
      }, {
        "name" : "Mabinogi",
        "isDisabled" : false
      }, {
        "name" : "Makeup",
        "isDisabled" : false
      }, {
        "name" : "MapleStory",
        "isDisabled" : false
      }, {
        "name" : "Marc Benioff",
        "isDisabled" : false
      }, {
        "name" : "Marketing",
        "isDisabled" : false
      }, {
        "name" : "Marvel Universe",
        "isDisabled" : false
      }, {
        "name" : "McDonald's",
        "isDisabled" : false
      }, {
        "name" : "Men's boxing",
        "isDisabled" : false
      }, {
        "name" : "Model figures",
        "isDisabled" : false
      }, {
        "name" : "Monster Hunter",
        "isDisabled" : false
      }, {
        "name" : "Motorcycles",
        "isDisabled" : false
      }, {
        "name" : "Movies",
        "isDisabled" : false
      }, {
        "name" : "Movies",
        "isDisabled" : false
      }, {
        "name" : "Movies & TV",
        "isDisabled" : false
      }, {
        "name" : "Mr Love: Queen's Choice",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Music",
        "isDisabled" : false
      }, {
        "name" : "Musical instruments",
        "isDisabled" : false
      }, {
        "name" : "Nails",
        "isDisabled" : false
      }, {
        "name" : "Nature",
        "isDisabled" : false
      }, {
        "name" : "Naver",
        "isDisabled" : false
      }, {
        "name" : "Netflix",
        "isDisabled" : false
      }, {
        "name" : "New Years Eve",
        "isDisabled" : false
      }, {
        "name" : "News",
        "isDisabled" : false
      }, {
        "name" : "News Outlets",
        "isDisabled" : false
      }, {
        "name" : "Nexon",
        "isDisabled" : false
      }, {
        "name" : "Nexus: The Kingdom of the Winds",
        "isDisabled" : false
      }, {
        "name" : "Nier: Automata",
        "isDisabled" : false
      }, {
        "name" : "Nintendo",
        "isDisabled" : false
      }, {
        "name" : "Nintendo Switch",
        "isDisabled" : false
      }, {
        "name" : "ONE PIECE",
        "isDisabled" : false
      }, {
        "name" : "Ongoing news stories",
        "isDisabled" : false
      }, {
        "name" : "Outdoors",
        "isDisabled" : false
      }, {
        "name" : "Overwatch",
        "isDisabled" : false
      }, {
        "name" : "Overwatch League",
        "isDisabled" : false
      }, {
        "name" : "PC gaming",
        "isDisabled" : false
      }, {
        "name" : "PUMA",
        "isDisabled" : false
      }, {
        "name" : "Park Myungsoo",
        "isDisabled" : false
      }, {
        "name" : "Park Woojin",
        "isDisabled" : false
      }, {
        "name" : "Peing - 質問箱",
        "isDisabled" : false
      }, {
        "name" : "Perfumes",
        "isDisabled" : false
      }, {
        "name" : "Perfumes & fragrances",
        "isDisabled" : false
      }, {
        "name" : "Persona",
        "isDisabled" : false
      }, {
        "name" : "Photography",
        "isDisabled" : false
      }, {
        "name" : "Photography",
        "isDisabled" : false
      }, {
        "name" : "Piano",
        "isDisabled" : false
      }, {
        "name" : "Pilates",
        "isDisabled" : false
      }, {
        "name" : "Pizza",
        "isDisabled" : false
      }, {
        "name" : "PlayStation",
        "isDisabled" : false
      }, {
        "name" : "PlayStation 4",
        "isDisabled" : false
      }, {
        "name" : "Podcasts & radio",
        "isDisabled" : false
      }, {
        "name" : "Pokemon anime -1",
        "isDisabled" : false
      }, {
        "name" : "Pokemon anime -2",
        "isDisabled" : false
      }, {
        "name" : "Pokemon trading card games -2",
        "isDisabled" : false
      }, {
        "name" : "Pokemon video games -2",
        "isDisabled" : false
      }, {
        "name" : "Pokémon",
        "isDisabled" : false
      }, {
        "name" : "Pokémon GO",
        "isDisabled" : false
      }, {
        "name" : "Pretty Cure",
        "isDisabled" : false
      }, {
        "name" : "Psychology",
        "isDisabled" : false
      }, {
        "name" : "RM",
        "isDisabled" : false
      }, {
        "name" : "Ramen",
        "isDisabled" : false
      }, {
        "name" : "Rap",
        "isDisabled" : false
      }, {
        "name" : "Red Dead Redemption",
        "isDisabled" : false
      }, {
        "name" : "Rockstar Games",
        "isDisabled" : false
      }, {
        "name" : "Romance books",
        "isDisabled" : false
      }, {
        "name" : "Rum",
        "isDisabled" : false
      }, {
        "name" : "SBS",
        "isDisabled" : false
      }, {
        "name" : "SINoALICE",
        "isDisabled" : false
      }, {
        "name" : "SUGA",
        "isDisabled" : false
      }, {
        "name" : "Salad",
        "isDisabled" : false
      }, {
        "name" : "Samsung",
        "isDisabled" : false
      }, {
        "name" : "Samsung Indonesia",
        "isDisabled" : false
      }, {
        "name" : "Sci-fi & fantasy",
        "isDisabled" : false
      }, {
        "name" : "Science",
        "isDisabled" : false
      }, {
        "name" : "Science news",
        "isDisabled" : false
      }, {
        "name" : "Scorpio",
        "isDisabled" : false
      }, {
        "name" : "Seven Knights",
        "isDisabled" : false
      }, {
        "name" : "Shoes",
        "isDisabled" : false
      }, {
        "name" : "Soccer",
        "isDisabled" : false
      }, {
        "name" : "Social media",
        "isDisabled" : false
      }, {
        "name" : "Soda",
        "isDisabled" : false
      }, {
        "name" : "Space",
        "isDisabled" : false
      }, {
        "name" : "Space News",
        "isDisabled" : false
      }, {
        "name" : "Space and astronomy",
        "isDisabled" : false
      }, {
        "name" : "Sports",
        "isDisabled" : false
      }, {
        "name" : "Square Enix",
        "isDisabled" : false
      }, {
        "name" : "Starbucks",
        "isDisabled" : false
      }, {
        "name" : "Suits",
        "isDisabled" : false
      }, {
        "name" : "Super Smash Bros.",
        "isDisabled" : false
      }, {
        "name" : "Sushi",
        "isDisabled" : false
      }, {
        "name" : "Tabletop gaming",
        "isDisabled" : false
      }, {
        "name" : "Tabletop role-playing games",
        "isDisabled" : false
      }, {
        "name" : "Tech news",
        "isDisabled" : false
      }, {
        "name" : "Tech personalities",
        "isDisabled" : false
      }, {
        "name" : "Technology",
        "isDisabled" : false
      }, {
        "name" : "Television",
        "isDisabled" : false
      }, {
        "name" : "Tetris",
        "isDisabled" : false
      }, {
        "name" : "The Legend of Zelda",
        "isDisabled" : false
      }, {
        "name" : "The New York Times",
        "isDisabled" : false
      }, {
        "name" : "Theater",
        "isDisabled" : false
      }, {
        "name" : "Theme parks",
        "isDisabled" : false
      }, {
        "name" : "Tinder",
        "isDisabled" : false
      }, {
        "name" : "Tottenham Hotspur",
        "isDisabled" : false
      }, {
        "name" : "Touken Ranbu",
        "isDisabled" : false
      }, {
        "name" : "Track & field",
        "isDisabled" : false
      }, {
        "name" : "Traditional games",
        "isDisabled" : false
      }, {
        "name" : "Travel",
        "isDisabled" : false
      }, {
        "name" : "Twitter",
        "isDisabled" : false
      }, {
        "name" : "V (BTS)",
        "isDisabled" : false
      }, {
        "name" : "Victon",
        "isDisabled" : false
      }, {
        "name" : "Video games",
        "isDisabled" : false
      }, {
        "name" : "Virtual YouTubers",
        "isDisabled" : false
      }, {
        "name" : "Visual arts",
        "isDisabled" : false
      }, {
        "name" : "Voice actors",
        "isDisabled" : false
      }, {
        "name" : "Watches",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Weather",
        "isDisabled" : false
      }, {
        "name" : "Webcomics",
        "isDisabled" : false
      }, {
        "name" : "Weddings",
        "isDisabled" : false
      }, {
        "name" : "Xbox",
        "isDisabled" : false
      }, {
        "name" : "Xbox One",
        "isDisabled" : false
      }, {
        "name" : "Yo Oizumi",
        "isDisabled" : false
      }, {
        "name" : "Yoga",
        "isDisabled" : false
      }, {
        "name" : "Yoo Jaesuk",
        "isDisabled" : false
      }, {
        "name" : "YouTube",
        "isDisabled" : false
      }, {
        "name" : "YouTubers",
        "isDisabled" : false
      }, {
        "name" : "hololive",
        "isDisabled" : false
      }, {
        "name" : "j-hope",
        "isDisabled" : false
      }, {
        "name" : "pixiv (ピクシブ)",
        "isDisabled" : false
      }, {
        "name" : "モーニングCROSS",
        "isDisabled" : false
      }, {
        "name" : "ワンピース",
        "isDisabled" : false
      } ],
      "partnerInterests" : [ ],
      "audienceAndAdvertisers" : {
        "numAudiences" : "0",
        "advertisers" : [ ],
        "lookalikeAdvertisers" : [ "@8ballpool", "@ABEMA", "@AirBrushApp", "@Alarm_Clock_App", "@AnotherEdenRPG", "@Apalon", "@B612_Indonesia", "@B612_Thailand", "@BAND_app_jp", "@BeautyFamily01", "@BeautyPlusApp", "@Beautyexpro", "@Beautyplus_in", "@BetterMe_Mind", "@BlossomPlant", "@CChannel_tv", "@ClashRoyaleJP", "@CocaColaJapan", "@Coloring_app", "@Coupang", "@DazzleStory", "@DuolingoBrasil", "@Duolingo_Japan", "@Eat24", "@FE_Heroes_JP", "@FastingWindow", "@Fontmania_app", "@Foodie_Official", "@Foodieapp_kr", "@GAME_KNIVES_OUT", "@GaeaF7", "@GrabID", "@HxH_WorldHunt", "@IAMEmperorKR", "@IdentityVJP", "@JOOXSouthAfrica", "@KL7", "@KrbsCC_App", "@KyleD", "@LINEGAME_Japan", "@LINE_tsumtsum_j", "@LINEmanga", "@LINEmangaPR", "@Live_Wallpaper_", "@MAppEntertain", "@MedaGAME", "@MedaMM24", "@MedaUTY", "@Meitu_global", "@Miitomo_JP", "@NAVER_SERIES", "@NarutoBlazingWW", "@NintendoAmerica", "@NintendoEurope", "@ONE_PIECE_TC", "@PERFMKTNG", "@PUBGMOBILE_JP", "@PicsArtjapan", "@PimpYourScreen", "@Planes_Live_app", "@PokemonGOAppJP", "@PokemonGoApp", "@SEGAHARDlight", "@SNOW_jp_SNOW", "@SODA_Korea", "@SODA_Thailand", "@Scanner_for_Me", "@SideM_LOS", "@SideM_official", "@Simeji_pr", "@Skyscanner", "@SkyscannerAus", "@SkyscannerBR", "@SkyscannerIN", "@SkyscannerIT", "@SkyscannerJapan", "@SkyscannerPH", "@SkyscannerSG", "@SkyscannerTR", "@SkyscannerUSA", "@Skyscanner_DE", "@Skyscanner_FR", "@Skyscanner_Ru", "@Skyscanner_nl", "@Sleepzyforme", "@Snap_Translate", "@SnapcalcS", "@SoundCloud", "@SpeakTranslate", "@SpotifyJP", "@Starbucks", "@StyleShareJP", "@StyleShare_twt", "@SuperMarioRunJP", "@TOUKEN_STAFF", "@TapeACall", "@TiktokKR", "@Tinder", "@Toss_service", "@Twitter", "@Uber", "@VLLO_Japan", "@VimoApp", "@VineCreators", "@Visa", "@Vliveofficial", "@VoezRayark", "@Warmlight_app", "@YanoljaOfficial", "@ZigBang", "@ZigZag", "@_AppServe", "@__AppLoad", "@_mobApp0", "@accelworld_sp", "@ahmadshafey", "@asteriskfesta", "@ayarabu_info", "@baki_app", "@bangdreamparty_", "@beautyplus_id", "@beautyplus_intl", "@beautypluscom", "@beautypluskorea", "@beautyplusth", "@better_me_app", "@brandiapp", "@catw_granbluefa", "@cleanmaster_jp", "@comico_jp", "@cooltimestudio", "@dailyburn", "@danmachimemoria", "@davis_support", "@devxoul", "@duolingo", "@eternallightKR", "@fun_channels", "@fun_kingdoms", "@ghoul_game", "@gismartmusic", "@granbluefantasy", "@gundam_ggame", "@heroaca_st", "@hwahae_official", "@iTranslateApp", "@idus_kr", "@imas_official", "@imasml_theater", "@jamlivetv", "@jojodr_app", "@jump_orecolle", "@life4_games", "@life4style01", "@lifeFantasti", "@lovenproducer", "@makeupplus_jp", "@makeupplusapp", "@mangaup_PR_ad", "@medaApp01", "@meitu_jp", "@meitu_kr", "@mercari_jp", "@mercari_wolf", "@mery_news", "@miraclenikkijp", "@monst_mixi", "@naruto_blazing", "@noaaradarlive", "@notepad_app", "@optc_kr", "@papago_jp", "@papegames", "@peaklabs", "@piccoma_jp", "@pinterestUK", "@planeslive", "@pokemori_jp", "@precure_app", "@productiveforme", "@rakuma_official", "@rakuma_tw", "@rakutenapp", "@robokiller", "@rpg_AE", "@ruroken_kengeki", "@saomd_gameinfo", "@saomd_ww", "@sdorica_rayark", "@seven_flags", "@shoumetsutoshi", "@sinoalice_jp", "@skyscanner_es", "@snow_kr_snow", "@sslegendwars", "@sssss_som", "@strspi", "@sumo_gameinfo", "@symphogear_XD", "@talesof_therays", "@thebandapp", "@tiktok_japan", "@tiktok_us", "@toas_promo", "@todayinterior", "@tokopedia", "@trapcall", "@triple_guide", "@tripstore_kr", "@tsukipara_app", "@tumblr", "@vsco", "@weatherlive_app", "@witapp_official", "@yogabydailyburn", "@yousician", "@zeroasuka", "@zhihao", "@76", "@AmazonJP", "@AudienseCo", "@BNYMellon", "@BookatableSE", "@BuildMyCadillac", "@BushmillsUSA", "@Cadillac", "@DairyQueen", "@EnSol_PR", "@FirestoneTires", "@Ford", "@HPE", "@HaagenDazs_US", "@Hallmark", "@IntelBusiness", "@KimKardashian", "@LGUS", "@LuckyCharms", "@MartellUSA", "@McDonalds", "@NRFnews", "@Nike", "@Phillips66Gas", "@SAPSmallBiz", "@SamsungUK", "@Spotify", "@SpotifyARG", "@SpotifyCanada", "@SpotifyKDaebak", "@SpotifyUK", "@Spotify_LATAM", "@SprintLatino", "@StarbucksCanada", "@SunshineCity_PR", "@T2Interactive", "@T2InteractiveUS", "@TDAmeritrade", "@TIDAL", "@TUMSOfficial", "@Target", "@TwitterSurveys", "@amazon", "@au_official", "@baristabar", "@buzzfeedpartner", "@bxfsh", "@cibc", "@ensemble_stars", "@intel", "@janellebruland", "@joeyjojo28", "@kfc", "@liveme4jp", "@managefeedback", "@mangabangfree", "@meshfire", "@netflix", "@nikeaustralia", "@onet_jp", "@pepsi", "@roadshow", "@spotifypodcasts", "@zozojp" ]
      },
      "shows" : [ "BEASTARS", "Fate/Apocrypha", "Fate/Apocrypha (Netflix)", "Fate/Zero", "Fate/stay night", "JoJo's Bizarre Adventure", "Live: NBA Basketball", "NBA Basketball", "Solar Eclipse 2017", "Suits", "デジモンアドベンチャー:", "モーニングCROSS", "半沢直樹", "幼女戦記", "弱虫ペダル", "忍たま乱太郎", "約束のネバーランド" ]
    },
    "locationHistory" : [ "Seodaemun-gu, Republic of Korea", "Sudogwon, Republic of Korea", "Namdong-gu, Republic of Korea" ],
    "inferredAgeInfo" : {
      "age" : [ "13-54" ],
      "birthDate" : ""
    }
  }
} ]