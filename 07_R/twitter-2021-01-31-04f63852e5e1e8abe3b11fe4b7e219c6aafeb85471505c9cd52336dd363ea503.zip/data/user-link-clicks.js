window.YTD.user_link_clicks.part0 = [ {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1349053258975698944",
      "finalUrl" : "https://fse.tw/NorflgWL#all",
      "timeStampOfInteraction" : "2021-01-13T09:55:10.903Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1326749061798486016",
      "finalUrl" : "https://lavierose.tistory.com/83",
      "timeStampOfInteraction" : "2021-01-26T08:42:01.666Z"
    }
  }
}, {
  "userInteractionsData" : {
    "linkClick" : {
      "tweetId" : "1354733355506384896",
      "finalUrl" : "https://m.hankookilbo.com/News/Read/201509041649606323",
      "timeStampOfInteraction" : "2021-01-29T00:02:16.616Z"
    }
  }
} ]